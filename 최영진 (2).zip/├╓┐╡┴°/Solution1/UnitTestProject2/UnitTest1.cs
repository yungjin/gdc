﻿using System;
using System.Collections;
using System.Data.SqlClient;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using DB;

namespace UnitTestProject2
{
    [TestClass]
    public class UnitTest1
    {
        private SqlConnection conn;
        public bool status;

        public UnitTest1()
        {
            status = Connection();
        }

        [TestMethod]
        public void connTest()
        {
            Assert.AreEqual(true, Connection());
        }
        [TestMethod]
        public void NonQueryTest()
        {
            string sql = "select * from [Member];";
            Assert.AreEqual(true, NonQuery(sql));
        }
        [TestMethod]
        public void ReaderTest()
        {
            string sql = "select * from [Member];";
            SqlDataReader sdr = Reader(sql);
            int ctn = 0;
            while (sdr.Read())
            {
                ctn++;
            }

            Console.WriteLine(ctn);
        }

        [TestMethod]
        public void ConnCloseTest()
        {
            Assert.AreEqual(true, ConnectionClose());
        }

        [TestMethod]
        public void SelectMember()
        {
            conn = new SqlConnection();
            Connection();
            string sql = "select mNo, mName from Member where delYn = 'N';";
            SqlDataReader sdr = Reader(sql);
            
            int ctn = 0;

            while (sdr.Read())
            {
                ctn++;
            }
            Console.WriteLine(ctn);
            ReaderClose(sdr);
        }

        [TestMethod]
        public void insertTest()
        {
            string sql = string.Format("insert into Member (mID, mPass, mName) values ('{0}','{1}','{2}');","아이디", "패스워드", "이름");
            Assert.AreEqual(true, NonQuery(sql));
        }

        [TestMethod]
        public void updatetTest()
        {
            string sql = string.Format("update Member set mID = '{1}', mPass = '{2}', mName = '{3}', modDate = getDate() where mNo = {0};", "1", "아뒤바꿈", "pw바꿈", "이름바꿈");
            Assert.AreEqual(true, NonQuery(sql));
        }

        //===============================================================================================================
        public bool Connection() 
        {
            string Check = "";
            string host = "(localdb)\\MSSQLLocalDB";
            string user = "root";
            string password = "1234";
            string db = "gdc";

            string connStr = string.Format("server={0};uid={1};password={2};database={3}", host, user, password, db);
            conn = new SqlConnection(connStr);

            try
            {
                conn.Open();
                this.conn = conn;
                return true;
                Check = "y";
                
            }
            catch
            {
                conn.Close();
                this.conn = null;
                return false;
                Check = "n";

            }
            Console.WriteLine(conn);
            Assert.AreEqual("y", Check);
        }

        public SqlDataReader Reader(string sql)
        {
            try
            {
                if (status)
                {
                    SqlCommand comm = new SqlCommand(sql, conn);
                    return comm.ExecuteReader();
                }
                else
                {
                    return null;
                }
            }
            catch
            {
                return null;
            }
        }

        public bool ConnectionClose()
        {
            try
            {
                conn.Close();
                //MessageBox.Show("MS-SQL 연결끊기 성공!");
                return true;
            }
            catch
            {
                //MessageBox.Show("MS-SQL 연결끊기 실패!");
                return false;
            }
        }

        public void ReaderClose(SqlDataReader reader)
        {
            reader.Close();
        }

        public bool NonQuery(string sql)
        {
            try
            {
                if (status)
                {
                    SqlCommand comm = new SqlCommand(sql, conn);
                    comm.ExecuteNonQuery();
                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch
            {
                return false;
            }
        }

        
    }
}
