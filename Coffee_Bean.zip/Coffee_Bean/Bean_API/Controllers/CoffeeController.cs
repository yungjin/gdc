using System;
using System.Collections;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Bean_API.Modules;
using MySql.Data.MySqlClient;
using Bean_API.Model;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;

namespace Bean_API.Controllers
{
    [ApiController]
    public class CoffeeController : ControllerBase
    {
        // Form1_Chart_all_Select // 차트그래???�체 ?�두 ?�??
        [Route("Form1_Chart_all_Select")]
        [HttpGet]
        public ActionResult<ArrayList> Form1_Chart_all_Select()
        {
            Console.WriteLine("select : Form1_Chart_all_Select");

            DataBase db = new DataBase();
            //string sql = "select book_number, availability, title, author, publisher from book_info;";
            MySqlDataReader sdr = db.P_Reader("Form1_Chart_all_Select");
            //MySqlDataReader sdr = db.CMDReader(sql);
            ArrayList list = new ArrayList();
            while(sdr.Read())
            {
                Hashtable ht = new Hashtable();
                for (int i = 0; i < sdr.FieldCount; i++)
                {
                    ht.Add(sdr.GetName(i).ToString(), sdr.GetValue(i).ToString());
                }
                list.Add(ht);
            }
            db.ReaderClose(sdr);
            db.Close();

            return list;
        }


        // Form1_Chart_all_Select // 차트그래???�체 ?�두 ?�??
        [Route("Form1_Chart_Roasting_select")]
        [HttpGet]
        public ActionResult<ArrayList> Form1_Chart_Roasting_select()
        {
            Console.WriteLine("select : Form1_Chart_Roasting_select");

            DataBase db = new DataBase();
            //string sql = "select book_number, availability, title, author, publisher from book_info;";
            MySqlDataReader sdr = db.P_Reader("Form1_Chart_Roasting_select");
            //MySqlDataReader sdr = db.CMDReader(sql);
            ArrayList list = new ArrayList();
            while(sdr.Read())
            {
                Hashtable ht = new Hashtable();
                for (int i = 0; i < sdr.FieldCount; i++)
                {
                    ht.Add(sdr.GetName(i).ToString(), sdr.GetValue(i).ToString());
                }
                list.Add(ht);
            }
            db.ReaderClose(sdr);
            db.Close();

            return list;
        }
        
        [Route("Form1_Chart_Product_select")]
        [HttpGet]
        public ActionResult<ArrayList> Form1_Chart_Product_select()
        {
            Console.WriteLine("select : Form1_Chart_Product_select");

            DataBase db = new DataBase();
            //string sql = "select book_number, availability, title, author, publisher from book_info;";
            MySqlDataReader sdr = db.P_Reader("Form1_Chart_Product_select");
            //MySqlDataReader sdr = db.CMDReader(sql);
            ArrayList list = new ArrayList();
            while(sdr.Read())
            {
                Hashtable ht = new Hashtable();
                for (int i = 0; i < sdr.FieldCount; i++)
                {
                    ht.Add(sdr.GetName(i).ToString(), sdr.GetValue(i).ToString());
                }
                list.Add(ht);
            }
            db.ReaderClose(sdr);
            db.Close();

            return list;
        }

        [Route("Form1_Chart_Bean_select")]
        [HttpGet]
        public ActionResult<ArrayList> Form1_Chart_Bean_select()
        {
            Console.WriteLine("select : Form1_Chart_Bean_select");

            DataBase db = new DataBase();
            //string sql = "select book_number, availability, title, author, publisher from book_info;";
            MySqlDataReader sdr = db.P_Reader("Form1_Chart_Bean_select");
            //MySqlDataReader sdr = db.CMDReader(sql);
            ArrayList list = new ArrayList();
            while(sdr.Read())
            {
                Hashtable ht = new Hashtable();
                for (int i = 0; i < sdr.FieldCount; i++)
                {
                    ht.Add(sdr.GetName(i).ToString(), sdr.GetValue(i).ToString());
                }
                list.Add(ht);
            }
            db.ReaderClose(sdr);
            db.Close();

            return list;
        }

        [Route("Form2_Machine_Name_all_Select")]
        [HttpGet]
        public ActionResult<ArrayList> Form2_Machine_Name_all_Select()
        {
            Console.WriteLine("select : Form2_Machine_Name_all_Select");

            DataBase db = new DataBase();
            //string sql = "select book_number, availability, title, author, publisher from book_info;";
            MySqlDataReader sdr = db.P_Reader("Form2_Machine_Name_all_Select");
            //MySqlDataReader sdr = db.CMDReader(sql);
            ArrayList list = new ArrayList();
            while(sdr.Read())
            {
                Hashtable ht = new Hashtable();
                for (int i = 0; i < sdr.FieldCount; i++)
                {
                    ht.Add(sdr.GetName(i).ToString(), sdr.GetValue(i).ToString());
                }
                list.Add(ht);
            }
            db.ReaderClose(sdr);
            db.Close();

            return list;
        }

        [Route("Form2_Bean_Name_all_Select")]
        [HttpGet]
        public ActionResult<ArrayList> Form2_Bean_Name_all_Select()
        {
            Console.WriteLine("select : Form2_Bean_Name_all_Select");

            DataBase db = new DataBase();
            //string sql = "select book_number, availability, title, author, publisher from book_info;";
            MySqlDataReader sdr = db.P_Reader("Form2_Bean_Name_all_Select");
            //MySqlDataReader sdr = db.CMDReader(sql);
            ArrayList list = new ArrayList();
            while(sdr.Read())
            {
                Hashtable ht = new Hashtable();
                for (int i = 0; i < sdr.FieldCount; i++)
                {
                    ht.Add(sdr.GetName(i).ToString(), sdr.GetValue(i).ToString());
                }
                list.Add(ht);
            }
            db.ReaderClose(sdr);
            db.Close();

            return list;
        }

        [Route("book_info_listview_click_select_post")]
        [HttpPost]
        public ActionResult<ArrayList> Book_info_listview_click_select_post([FromForm] string book_number)
        {
            Console.WriteLine("Book_info_listview_click_select_post-----");
            Console.WriteLine("book_number : " + book_number);

            DataBase db = new DataBase();
            //string sql = string.Format("select * from book_info where book_number = {0};", book_number);

            Hashtable ht = new Hashtable();
            ht.Add("_book_number", book_number);
			MySqlDataReader sdr = db.P_Reader_values("p_book_info_listview_click_select_post", ht);

            //MySqlDataReader sdr = db.CMDReader(sql);
            ArrayList list = new ArrayList();
            while(sdr.Read())
            {
                ht = new Hashtable();
                for (int i = 0; i < sdr.FieldCount; i++)
                {
                    ht.Add(sdr.GetName(i).ToString(), sdr.GetValue(i).ToString());
                }
                list.Add(ht);
            }
            db.ReaderClose(sdr);
            db.Close();

            return list;
        }

        [Route("Bean_Add_Update")]
		[HttpPost]
		public ActionResult<string> Bean_Add_Update([FromForm] string _Bean_Name,[FromForm] string _Gram)
		{
            Console.WriteLine("Bean_Add_Update");
            Console.WriteLine("_Bean_Name : " + _Bean_Name);
            Console.WriteLine("_Gram : " + _Gram);

            DataBase db = new DataBase();

            Hashtable ht = new Hashtable();
            ht.Add("_Bean_Name", _Bean_Name);
            ht.Add("_Gram", _Gram);
            
			//string sql = string.Format("UPDATE signup set passwod = '{0}' where user_number = {1};", passwod, user_number);
			if(db.P_NonQuery_Value("Bean_Add_Update", ht))
			{
				return "1";
			}
			else 
			{
				return "0";
			}
            db.Close();
		}

        [Route("Bean_Number_Select")]
		[HttpPost]
		public ActionResult<ArrayList> Bean_Number_Select([FromForm] string _Bean_Name)
		{
            
            Console.WriteLine("_Bean_Name : " + _Bean_Name);

			DataBase db = new DataBase();
            Hashtable ht = new Hashtable();
            ht.Add("_Bean_Name", _Bean_Name);
			MySqlDataReader sdr = db.P_Reader_values("Bean_Number_Select", ht);	

            ArrayList list = new ArrayList();
            while(sdr.Read())
            {
                ht = new Hashtable();
                for (int i = 0; i < sdr.FieldCount; i++)
                {
                    ht.Add(sdr.GetName(i).ToString(), sdr.GetValue(i).ToString());
                }
                list.Add(ht);
            }
            db.ReaderClose(sdr);
            db.Close();

            return list;
		}

        [Route("Machine_Number_Select")]
		[HttpPost]
		public ActionResult<ArrayList> Machine_Number_Select([FromForm] string _Machine_Name)
		{
            
            Console.WriteLine("_Machine_Name : " + _Machine_Name);

			DataBase db = new DataBase();
            Hashtable ht = new Hashtable();
            ht.Add("_Machine_Name", _Machine_Name);
			MySqlDataReader sdr = db.P_Reader_values("Machine_Number_Select", ht);	

            ArrayList list = new ArrayList();
            while(sdr.Read())
            {
                ht = new Hashtable();
                for (int i = 0; i < sdr.FieldCount; i++)
                {
                    ht.Add(sdr.GetName(i).ToString(), sdr.GetValue(i).ToString());
                }
                list.Add(ht);
            }
            db.ReaderClose(sdr);
            db.Close();

            return list;
		}

        [Route("Form2_Solo_Bean_Select")]
		[HttpPost]
		public ActionResult<ArrayList> Form2_Solo_Bean_Select([FromForm] string _Bean_Number)
		{
            Console.WriteLine("_Bean_Number : " + _Bean_Number);

			DataBase db = new DataBase();
            Hashtable ht = new Hashtable();
            ht.Add("_Bean_Number", _Bean_Number);
			MySqlDataReader sdr = db.P_Reader_values("Form2_Solo_Bean_Select", ht);	

            ArrayList list = new ArrayList();
            while(sdr.Read())
            {
                ht = new Hashtable();
                for (int i = 0; i < sdr.FieldCount; i++)
                {
                    ht.Add(sdr.GetName(i).ToString(), sdr.GetValue(i).ToString());
                }
                list.Add(ht);
            }
            db.ReaderClose(sdr);
            db.Close();

            return list;
		}

        [Route("Seting_Insert")]
		[HttpPost]
		public ActionResult<string> Seting_Insert([FromForm] string _Bean_Number,[FromForm] string _Gram,[FromForm] string _Machine_Number,[FromForm] string _Setting_Time)
		{
            Console.WriteLine("Seting_Insert");
            Console.WriteLine("_Bean_Number : " + _Bean_Number);
            Console.WriteLine("_Gram : " + _Gram);
            Console.WriteLine("_Machine_Number :" + _Machine_Number);
            Console.WriteLine("_Setting_Time :" + _Setting_Time);

            DataBase db = new DataBase();

            Hashtable ht = new Hashtable();
            ht.Add("_Bean_Number", _Bean_Number);
            ht.Add("_Gram", _Gram);
            ht.Add("_Machine_Number", _Machine_Number);
            ht.Add("_Setting_Time", _Setting_Time);
            
			//string sql = string.Format("UPDATE signup set passwod = '{0}' where user_number = {1};", passwod, user_number);
			if(db.P_NonQuery_Value("Seting_Insert", ht))
			{
				return "1";
			}
			else 
			{
				return "0";
			}
            db.Close();
		}

        [Route("Form2_Roasting_all_Select_2")]
        [HttpGet]
        public ActionResult<ArrayList> Form2_Roasting_all_Select_2()
        {
            Console.WriteLine("select : Form2_Roasting_all_Select_2");

            DataBase db = new DataBase();
            //string sql = "select book_number, availability, title, author, publisher from book_info;";
            MySqlDataReader sdr = db.P_Reader("Form2_Roasting_all_Select_2");
            //MySqlDataReader sdr = db.CMDReader(sql);
            ArrayList list = new ArrayList();
            while(sdr.Read())
            {
                Hashtable ht = new Hashtable();
                for (int i = 0; i < sdr.FieldCount; i++)
                {
                    ht.Add(sdr.GetName(i).ToString(), sdr.GetValue(i).ToString());
                }
                list.Add(ht);
            }
            db.ReaderClose(sdr);
            db.Close();

            return list;
        }

        [Route("Form2_FS_Check")]
		[HttpPost]
		public ActionResult<string> Form2_FS_Check([FromForm] string _Machine_Number,[FromForm] string _Roasting_Number,[FromForm] string _Bean_Number,[FromForm] string _Roasting_Gram)
		{
            Console.WriteLine("Form2_FS_Check");
            Console.WriteLine("_Machine_Number :" + _Machine_Number);
            Console.WriteLine("_Roasting_Number :" + _Roasting_Number);
            Console.WriteLine("_Bean_Number :" + _Bean_Number);
            Console.WriteLine("_Roasting_Gram :" + _Roasting_Gram);
            

            DataBase db = new DataBase();

            Hashtable ht = new Hashtable();
            ht.Add("_Machine_Number", _Machine_Number);
            
			//string sql = string.Format("UPDATE signup set passwod = '{0}' where user_number = {1};", passwod, user_number);
			if(db.P_NonQuery_Value("Form2_FS_Check", ht))
			{
				return "1";
			}
			else 
			{
				return "0";
			}
            db.Close();
		}

        [Route("Form2_Fs_Check_all_Select")]
		[HttpPost]
		public ActionResult<ArrayList> Form2_Fs_Check_all_Select([FromForm] string _Machine_Number)
		{
            Console.WriteLine("Form2_Fs_Check_all_Select");
            Console.WriteLine("_Machine_Number : " + _Machine_Number);

			DataBase db = new DataBase();
            Hashtable ht = new Hashtable();
            ht.Add("_Machine_Number", _Machine_Number);
			MySqlDataReader sdr = db.P_Reader_values("Form2_Fs_Check_all_Select", ht);	

            ArrayList list = new ArrayList();
            while(sdr.Read())
            {
                ht = new Hashtable();
                for (int i = 0; i < sdr.FieldCount; i++)
                {
                    ht.Add(sdr.GetName(i).ToString(), sdr.GetValue(i).ToString());
                }
                list.Add(ht);
            }
            db.ReaderClose(sdr);
            db.Close();

            return list;
		}
        [Route("Form2_Date_slect")]
		[HttpPost]
		public ActionResult<ArrayList> Form2_Date_slect([FromForm] string _Machine_Number)
		{
            Console.WriteLine("Form2_Date_slect");
            Console.WriteLine("_Machine_Number : " + _Machine_Number);

			DataBase db = new DataBase();
            Hashtable ht = new Hashtable();
            ht.Add("_Machine_Number", _Machine_Number);
			MySqlDataReader sdr = db.P_Reader_values("Form2_Date_slect", ht);	

            ArrayList list = new ArrayList();
            while(sdr.Read())
            {
                ht = new Hashtable();
                for (int i = 0; i < sdr.FieldCount; i++)
                {
                
                    ht.Add(sdr.GetName(i).ToString(), sdr.GetValue(i).ToString());
                }
                list.Add(ht);
            }
            db.ReaderClose(sdr);
            db.Close();

            return list;
		}

        [Route("Select_Params")]
        [HttpPost]
        public ActionResult<ArrayList> Select_Params([FromForm] Param param)
        {
            Console.WriteLine("Select_Params : " + param.ParamMap);
            DataBase db = new DataBase();
            Hashtable ht = new Hashtable();
            string sql = param.CommandText;
            JObject jo = JsonConvert.DeserializeObject<JObject>(param.ParamMap);
            foreach (JProperty col in jo.Properties())
            {
                ht.Add(col.Name, col.Value);
            }
            MySqlDataReader sdr = db.P_Reader_values(sql, ht);
            ArrayList list = new ArrayList();
            if(sdr != null)
            {
                while (sdr.Read())
                {
                    string[] arr = new string[sdr.FieldCount];
                    for (int i = 0; i < sdr.FieldCount; i++)
                    {
                        arr[i] = sdr.GetValue(i).ToString();
                    }
                    list.Add(arr);
                }
                db.ReaderClose(sdr);
            }            
            db.Close();
            return list;
        }

        [Route("Form3_Product_Update")]
		[HttpPost]
		public ActionResult<string> Form3_Product_Update([FromForm] string _Product_Number)
		{
            Console.WriteLine("Form3_Product_Update");
            Console.WriteLine("_Product_Number : " + _Product_Number);

            DataBase db = new DataBase();

            Hashtable ht = new Hashtable();
            ht.Add("_Product_Number", _Product_Number);
            
			//string sql = string.Format("UPDATE signup set passwod = '{0}' where user_number = {1};", passwod, user_number);
			if(db.P_NonQuery_Value("Form3_Product_Update", ht))
			{
				return "1";
			}
			else 
			{
				return "0";
			}
            db.Close();
		}

        
        [Route("Form4_Product_Update")]
		[HttpPost]
		public ActionResult<string> Form4_Product_Update([FromForm] string _Product_Number)
		{
            Console.WriteLine("Form4_Product_Update");
            Console.WriteLine("_Product_Number : " + _Product_Number);

            DataBase db = new DataBase();

            Hashtable ht = new Hashtable();
            ht.Add("_Product_Number", _Product_Number);
            
			//string sql = string.Format("UPDATE signup set passwod = '{0}' where user_number = {1};", passwod, user_number);
			if(db.P_NonQuery_Value("Form4_Product_Update", ht))
			{
				return "1";
			}
			else 
			{
				return "0";
			}
            db.Close();
		}
        [Route("Form4_Product_Select")]
        [HttpGet]
        public ActionResult<ArrayList> Form4_Product_Select()
        {
            Console.WriteLine("select : Form4_Product_Select");

            DataBase db = new DataBase();
            //string sql = "select book_number, availability, title, author, publisher from book_info;";
            MySqlDataReader sdr = db.P_Reader("Form4_Product_Select");
            //MySqlDataReader sdr = db.CMDReader(sql);
            ArrayList list = new ArrayList();
            while(sdr.Read())
            {
                Hashtable ht = new Hashtable();
                for (int i = 0; i < sdr.FieldCount; i++)
                {
                    ht.Add(sdr.GetName(i).ToString(), sdr.GetValue(i).ToString());
                }
                list.Add(ht);
            }
            db.ReaderClose(sdr);
            db.Close();

            return list;
        }

        
    }
}
