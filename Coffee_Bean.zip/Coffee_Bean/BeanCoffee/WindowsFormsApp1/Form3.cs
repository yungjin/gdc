﻿using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;
using WindowsFormsApp;

namespace WindowsFormsApp1
{
    public partial class Form3 : Form
    {
        private List<int> _valueList1;
        Chart chart1;
        public Form3()
        {
            InitializeComponent();
            Load += Form3_Load;
        }
        string p_no;
        private ListView lv;
        LISTVIEWclass lv_value;
        COMMON_Create_Ctl comm;
        ComboBox combo1, combo2;
        Chart chart2;
        Panel panel1;
        private void Form3_Load(object sender, EventArgs e)
        {
            this.FormBorderStyle = FormBorderStyle.None;// 폼 상단 표시줄 제거
            this.Dock = DockStyle.Fill; //판넬크기에 맞게 사이즈 늘림.

            this.BackColor = Color.FromArgb(163, 127, 74);// 폼 백컬러
            comm = new COMMON_Create_Ctl();
            //판넬
            panel1 = new Panel();
            panel1.BackColor = Color.FromArgb(237, 227, 183);
            panel1.Size = new Size(1170, 700);
            panel1.Location = new Point(50, 50);
            panel1.Region = Region.FromHrgn(COMMON_Create_Ctl.CreateRoundRectRgn(2, 2, panel1.Width, panel1.Height, 15, 15));
            //리스트뷰
            lv_value = new LISTVIEWclass(this, "ListView1", 780, 350, 350, 80, listView_MouseClick, listview_mousedoubleclick, 8, "", 0, "머신", 110, "원두", 150, "용량", 80, "로스팅 완료시간", 220, "숙성 완료 시간", 220, "check", 0,"End",0);
            lv = comm.listView(lv_value);
            panel1.Controls.Add(lv);
            lv.Font = new Font("Arial", 18, FontStyle.Bold);

            //콤보박스
            //ArrayList Muchine_list = new ArrayList();

            ArrayList ComboArry = Select_Webapi("Form2_Machine_Name_all_Select");
            /*
            foreach (Hashtable ht in ComboArry)
            {
                Muchine_list.Add(ht["Machine_Name"].ToString());
            }
            */

            combo1 = new ComboBox();
            combo1.Size = new Size(300, 300);
            combo1.Location = new Point(40, 80);
            combo1.Name = "콤보1";
            combo1.SelectedIndexChanged += Combo1_SelectedIndexChanged;
            combo1.Font = new Font(combo1.Font.Name, 27, FontStyle.Regular);
            combo1.DropDownStyle = ComboBoxStyle.DropDownList;
            Dictionary<string, string> dict = new Dictionary<string, string>();
            foreach (Hashtable ht in ComboArry)
            {
                dict.Add(ht["Machine_Number"].ToString(), ht["Machine_Name"].ToString());
                //combo1.Items.Add(ht["Machine_Name"].ToString());
            }
            combo1.DataSource = new BindingSource(dict, null);
            combo1.DisplayMember = "Value";
            combo1.ValueMember = "Key";
            /*
            for (int i = 0; i < Muchine_list.Count; i++)
            {
                combo1.Items.Add(Muchine_list[i]);
            }
            */
            panel1.Controls.Add(combo1);
            //차트그래프

            chart2 = new Chart();

            ChartArea chartArea2 = new ChartArea();
            Legend legend2 = new Legend();
            Series series2 = new Series();

            chartArea2.Name = "ChartArea2";
            legend2.Name = "Legend2";
            series2.ChartArea = "ChartArea2";
            series2.ChartType = SeriesChartType.Doughnut;
            series2.Legend = "Legend2";
            series2.Name = "Series2";
            chartArea2.BackColor = Color.FromArgb(237, 227, 183);// 배경색상
            legend2.BackColor = Color.FromArgb(237, 227, 183);// 배경색상

            chart2.Name = "chart2";
            chart2.Size = new Size(310, 310);
            chart2.Location = new Point(80, 150);
            chart2.Text = "chart2";
            chart2.ChartAreas.Add(chartArea2);
            chart2.Legends.Add(legend2);
            chart2.Series.Add(series2);
            chart2.BackColor = Color.FromArgb(237, 227, 183);

            ArrayList arry1 = Select_Webapi("Form1_Chart_Product_select");
            chart2.Series["Series2"].IsValueShownAsLabel = true;
            foreach (Hashtable ht in arry1) // 이름 , 그램 차트그래프 데이터 삽입 
            {
                chart2.Series["Series2"].Points.AddXY(ht["col1"].ToString(), ht["col2"].ToString());

            }
            panel1.Controls.Add(chart2);
            //버튼 =================================================================
            Button btn = comm.btn(new BTNclass(this, "포 장", "포 장", 400, 200, 710, 450, btn1_Click));
            btn.Font = new Font("견명조", 20F, FontStyle.Bold, GraphicsUnit.Point, ((byte)(129)));  // FontStyle.Regular
            btn.FlatStyle = FlatStyle.Flat;
            btn.ForeColor = Color.White;
            btn.BackColor = Color.FromArgb(80, 200, 223);
            btn.Region = Region.FromHrgn(COMMON_Create_Ctl.CreateRoundRectRgn(2, 2, btn.Width, btn.Height, 15, 15));
            btn.BackColor = Color.FromArgb(218, 234, 244);  // rgb(218,234,244)
            btn.Enabled = false;
            panel1.Controls.Add(btn);

            this.Controls.Add(panel1);
            //start();
        }

        private void btn1_Click(object sender, EventArgs e)
        {
            lv.Items.Clear();
            Form3_Product_Update(p_no);
            string Machine_Number = combo1.SelectedValue.ToString();
            JObject jo = new JObject();
            jo.Add("_Machine_Number", Machine_Number);

            ArrayList arry = Select_Params_Webapi("From3_", jo.ToString());
            lv.Items.Clear();
            foreach (JArray aRow in arry)
            {
                string[] row = new string[aRow.Count];
                for (int i = 0; i < aRow.Count; i++)
                {
                    row[i] = aRow[i].ToString();
                }
                lv.Items.Add(new ListViewItem(row));
            }
        }

        private void listview_mousedoubleclick(object sender, MouseEventArgs e)
        {
            
        }

        private void listView_MouseClick(object sender, MouseEventArgs e)
        {
            Control btn = null;
            foreach (Control ctr in panel1.Controls)
            {
                if (ctr.Name == "포 장")
                {
                    btn = ctr;
                }
            }
            ListView lView = (ListView)sender;
            ListViewItem item = lView.SelectedItems[0];

            ListView lv = (ListView)sender;
            ListView.SelectedListViewItemCollection slv = lv.SelectedItems;
            for (int i = 0; i < slv.Count; i++)
            {
                ListViewItem item1 = slv[i];
                p_no = item1.SubItems[6].Text;
            }

            if (Convert.ToInt32(item.SubItems[7].Text) < 0)
            {
                btn.Enabled = false;
                btn.BackColor = Color.FromArgb(218, 234, 244);
            }
            else
            {
                btn.Enabled = true;
                btn.BackColor = Color.FromArgb(52, 152, 219);
            }
        }

        private void Combo1_SelectedIndexChanged(object sender, EventArgs e) //콤보박스 선택시 실행
        {
            string Machine_Number = combo1.SelectedValue.ToString();
            JObject jo = new JObject();
            jo.Add("_Machine_Number", Machine_Number);
            //MessageBox.Show(jo.ToString());
            ArrayList arry = Select_Params_Webapi("From3_", jo.ToString());
            lv.Items.Clear();
            foreach (JArray aRow in arry)
            {
                string[] row = new string[aRow.Count];
                for(int i = 0; i < aRow.Count; i++)
                {
                    row[i] = aRow[i].ToString();
                }
                lv.Items.Add(new ListViewItem(row));
            }
        }

        private void AddData()
        {
            //_valueList1.Add(System.DateTime.Now.Second);
            _valueList1.Add(new Random().Next(0, 100));
            DateTime now = DateTime.Now;
            if (chart1.Series[0].Points.Count > 0)
            {
                while (chart1.Series[0].Points[0].XValue < now.AddSeconds(-60).ToOADate())
                {
                    chart1.Series[0].Points.RemoveAt(0);
                    chart1.ChartAreas[0].AxisX.Minimum = chart1.Series[0].Points[0].XValue;
                    chart1.ChartAreas[0].AxisX.Maximum = now.AddSeconds(0).ToOADate();
                }
            }
            chart1.Series[0].Points.AddXY(now.ToOADate(), _valueList1[_valueList1.Count - 1]);
            chart1.Invalidate();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            AddData();
        }
        private void start()
        {
            timer1.Interval = 1000;
            timer1.Start();
        }

        public ArrayList Select_Webapi(string controll_name)//셀렉트
        {
            WebClient client = new WebClient();
            //NameValueCollection data = new NameValueCollection();
            client.Headers.Add("user-agent", "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.2; .NET CLR 1.0.3705;)");
            client.Encoding = Encoding.UTF8;    //한글처리

            string url = "http://gdc3.gudi.kr:49001/" + controll_name;
            Stream result = client.OpenRead(url);

            StreamReader sr = new StreamReader(result);
            string str = sr.ReadToEnd();

            ArrayList jList = JsonConvert.DeserializeObject<ArrayList>(str);
            ArrayList list = new ArrayList();
            foreach (JObject row in jList)
            {
                Hashtable ht = new Hashtable();
                foreach (JProperty col in row.Properties())
                {
                    ht.Add(col.Name, col.Value);
                }
                list.Add(ht);
            }

            return list;
        }

        public ArrayList Select_Params_Webapi(string sql, string param)
        {
            WebClient client = new WebClient();
            NameValueCollection data = new NameValueCollection();
            client.Headers.Add("user-agent", "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.2; .NET CLR 1.0.3705;)");
            client.Encoding = Encoding.UTF8;

            string url = "http://gdc3.gudi.kr:49001/" + "Select_Params";
            string method = "POST";

            data.Add("CommandText", sql);
            data.Add("ParamMap", param);

            byte[] result = client.UploadValues(url, method, data);
            string strResult = Encoding.UTF8.GetString(result);
            return JsonConvert.DeserializeObject<ArrayList>(strResult);
        }

        public bool Form3_Product_Update(string _Product_Number)
        {
            WebClient client = new WebClient();
            NameValueCollection data = new NameValueCollection();
            client.Headers.Add("user-agent", "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.2; .NET CLR 1.0.3705;)");
            client.Encoding = Encoding.UTF8;

            string url = "http://gdc3.gudi.kr:49001/" + "Form3_Product_Update";
            string method = "POST";

            data.Add("_Product_Number", _Product_Number);

            byte[] result = client.UploadValues(url, method, data);
            string strResult = Encoding.UTF8.GetString(result);

            bool success_chk;
            if (strResult == "1")
            {
                success_chk = true;
            }
            else
            {
                success_chk = false;
            }

            return success_chk;
        }
    }
}
