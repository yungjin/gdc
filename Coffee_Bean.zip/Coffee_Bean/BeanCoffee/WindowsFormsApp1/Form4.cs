﻿using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;
using WindowsFormsApp;

namespace WindowsFormsApp1
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();
            Load += Form4_Load;
        }
        Panel panel1;
        Panel panel2;
        string p_no;
        TextBox Tb1, Tb2, Tb3, Tb4 = new TextBox();
        ComboBox combo1, combo2;
        private ListView lv,lv2;
        LISTVIEWclass lv_value, lv_value2;
        Chart chart4;
        COMMON_Create_Ctl comm;
        ArrayList urlList;
        
        private void Form4_Load(object sender, EventArgs e)
        {
            this.FormBorderStyle = FormBorderStyle.None;// 폼 상단 표시줄 제거
            this.Dock = DockStyle.Fill; //판넬크기에 맞게 사이즈 늘림.

            this.BackColor = Color.FromArgb(163, 127, 74);// 폼 백컬러
            comm = new COMMON_Create_Ctl();
            //판넬
            
            panel1 = new Panel();
            panel1.BackColor = Color.FromArgb(237, 227, 183);
            panel1.Size = new Size(580, 700);
            panel1.Location = new Point(50, 50);
            panel1.Region = Region.FromHrgn(COMMON_Create_Ctl.CreateRoundRectRgn(2, 2, panel1.Width, panel1.Height, 15, 15));

            panel2 = new Panel();
            panel2.BackColor = Color.FromArgb(237, 227, 183);
            panel2.Size = new Size(580, 700);
            panel2.Location = new Point(660, 50);
            panel2.Region = Region.FromHrgn(COMMON_Create_Ctl.CreateRoundRectRgn(2, 2, panel1.Width, panel1.Height, 15, 15));

            this.Controls.Add(panel1);
            this.Controls.Add(panel2);
            //버튼
            ArrayList btnArray = new ArrayList();
            btnArray.Add(new BTNclass(this, "입고", "입고", 150, 80, 400, 610, btn1_Click));
            btnArray.Add(new BTNclass(this, "출고", "출고", 150, 80, 400, 610, btn2_Click));

            for (int i = 0; i < btnArray.Count; i++)
            {
                Button btn = comm.btn((BTNclass)btnArray[i]);

                if (btn.Name == "입고")
                {
                    btn.Font = new Font("견명조", 20F, FontStyle.Bold, GraphicsUnit.Point, ((byte)(129)));  // FontStyle.Regular
                    btn.FlatStyle = FlatStyle.Flat;
                    btn.ForeColor = Color.White;
                    btn.BackColor = Color.FromArgb(80, 200, 223);
                    btn.Region = Region.FromHrgn(COMMON_Create_Ctl.CreateRoundRectRgn(2, 2, btn.Width, btn.Height, 15, 15));
                    btn.BackColor = Color.FromArgb(52, 152, 219);  // rgb(218,234,244)
                    panel1.Controls.Add(btn);
                }
                else if (btn.Name == "출고")
                {
                    btn.Font = new Font("견명조", 20F, FontStyle.Bold, GraphicsUnit.Point, ((byte)(129)));  // FontStyle.Regular
                    btn.FlatStyle = FlatStyle.Flat;
                    btn.ForeColor = Color.White;
                    btn.BackColor = Color.FromArgb(80, 200, 223);
                    btn.Region = Region.FromHrgn(COMMON_Create_Ctl.CreateRoundRectRgn(2, 2, btn.Width, btn.Height, 15, 15));
                    btn.BackColor = Color.FromArgb(52, 152, 219);  // rgb(218,234,244)
                    panel2.Controls.Add(btn);
                }
            }

            
            LBclass lb1 = new LBclass(this, "label1", "label_name~", 24, 100, 100, 10, 10);
            ArrayList lbarray = new ArrayList();
            lbarray.Add(new LBclass(this, "원두", "원두 :", 15, 100, 40, 20, 50));
            lbarray.Add(new LBclass(this, "용량", "용량(단위KG) :", 15, 250, 40, 20, 120));

            for (int i = 0; i < lbarray.Count; i++)
            {

                Label lb = comm.lb((LBclass)lbarray[i]);

                lb.Font = new Font("견명조", 25F, FontStyle.Bold, GraphicsUnit.Point, ((byte)(129)));

                panel1.Controls.Add(lb);
            }

            ArrayList Bean_list = new ArrayList();

            ArrayList ComboArry2 = Select_Webapi("Form2_Bean_Name_all_Select");
            foreach (Hashtable ht in ComboArry2)
            {
                Bean_list.Add(ht["Bean_Name"].ToString());
            }

            combo2 = new ComboBox();
            combo2.Size = new Size(300, 300);
            combo2.Location = new Point(270, 50);
            combo2.Name = "콤보2";
            combo2.SelectedIndexChanged += Combo2_SelectedIndexChanged;
            combo2.Font = new Font(combo2.Font.Name, 27, FontStyle.Regular);
            combo2.DropDownStyle = ComboBoxStyle.DropDownList;
            for (int i = 0; i < Bean_list.Count; i++)
            {
                combo2.Items.Add(Bean_list[i]);
            }
            panel1.Controls.Add(combo2);

            Tb1 = comm.txtbox(new TXTBOXclass(this, "용량", "20", 150, 40, 280, 120, Tb_click));
            Tb1.Font = new Font(combo2.Font.Name, 27, FontStyle.Regular);
            panel1.Controls.Add(Tb1);
            

            //리스트뷰


            lv_value2 = new LISTVIEWclass(this, "ListView1", 530, 500, 25, 100, listView_MouseClick, listview_mousedoubleclick, 5, "", 0, "원두", 150, "용량", 120, "포장완료 시간", 250, "", 0, "", 0);
            lv2 = comm.listView(lv_value2);
            panel2.Controls.Add(lv2);
            lv2.Font = new Font("Arial", 18, FontStyle.Bold);

            List_Views();

            // 차트
            chart4 = new Chart();
            ChartArea chartArea4 = new ChartArea();
            Legend legend4 = new Legend();
            Series series4 = new Series();

            urlList = new ArrayList();
            Hashtable urlMap = null;

            chartArea4.Name = "ChartArea4";
            legend4.Name = "Legend4";
            series4.ChartArea = "ChartArea4";
            series4.ChartType = SeriesChartType.Doughnut;
            series4.Legend = "Legend4";
            series4.Name = "Series4";
            chartArea4.BackColor = Color.FromArgb(237, 227, 183);// 배경색상
            legend4.BackColor = Color.FromArgb(237, 227, 183);// 배경색상

            chart4.Name = "chart4";
            chart4.Size = new Size(450, 450);
            chart4.Location = new Point(100, 220);
            chart4.Text = "chart4";
            chart4.ChartAreas.Add(chartArea4);
            chart4.Legends.Add(legend4);
            chart4.Series.Add(series4);
            chart4.BackColor = Color.FromArgb(237, 227, 183);
            chart4.Series["Series4"].IsValueShownAsLabel = true;
            urlMap = new Hashtable();
            urlMap.Add("url", "Form1_Chart_Bean_select");
            urlMap.Add("dpc", chart4.Series["Series4"].Points);
            urlList.Add(urlMap);
            
            panel1.Controls.Add(chart4);
            GetData();

        }

        private void Tb_click(object sender, EventArgs e)
        {
            
        }

        private void Combo2_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }
        public void GetData()
        {
            foreach (Hashtable map in urlList)
            {
                ArrayList arry = Select_Webapi(map["url"].ToString());
                foreach (Hashtable ht in arry) // 이름 , 그램 차트그래프 데이터 삽입 
                {
                    DataPointCollection dpc = (DataPointCollection)map["dpc"];
                    dpc.AddXY(ht["col1"].ToString(), ht["col2"].ToString());
                }
            }
        }

        private void btn2_Click(object sender, EventArgs e)
        {
            if (Form4_Product_Update(p_no)) MessageBox.Show("출고 완료");
            else MessageBox.Show("출고 오류");

            List_Views();

        }

        private void btn1_Click(object sender, EventArgs e)
        {
            if (Bean_Add_Update(combo2.Text, Tb1.Text))
            {
                MessageBox.Show("입고 완료");
            }
            else
            {
                MessageBox.Show("입고 오류");
            }
            chart4.Series["Series4"].Points.Clear();
            GetData();
        }

        private void listview_mousedoubleclick(object sender, MouseEventArgs e)
        {
            
        }

        private void listView_MouseClick(object sender, MouseEventArgs e)
        {
            ListView lv = (ListView)sender;
            ListView.SelectedListViewItemCollection slv = lv.SelectedItems;
            for (int i = 0; i < slv.Count; i++)
            {
                ListViewItem item1 = slv[i];
                p_no = item1.SubItems[0].Text;
            }
        }

        public void List_Views()//리스트뷰 셀렉트
        {
            lv2.Items.Clear();
            ArrayList arry = Select_Webapi("Form4_Product_Select");
            foreach (Hashtable ht in arry)
            {
                ListViewItem item = new ListViewItem(ht["번호"].ToString());
                item.SubItems.Add(ht["원두"].ToString());
                item.SubItems.Add(ht["용량"].ToString());
                item.SubItems.Add(ht["포장날짜"].ToString());
                lv2.Items.Add(item);
            }

            panel2.Controls.Add(lv2);

        }

        public ArrayList Select_Webapi(string controll_name)//셀렉트
        {
            WebClient client = new WebClient();
            //NameValueCollection data = new NameValueCollection();
            client.Headers.Add("user-agent", "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.2; .NET CLR 1.0.3705;)");
            client.Encoding = Encoding.UTF8;    //한글처리

            string url = "http://gdc3.gudi.kr:49001/" + controll_name;
            Stream result = client.OpenRead(url);

            StreamReader sr = new StreamReader(result);
            string str = sr.ReadToEnd();

            ArrayList jList = JsonConvert.DeserializeObject<ArrayList>(str);
            ArrayList list = new ArrayList();
            foreach (JObject row in jList)
            {
                Hashtable ht = new Hashtable();
                foreach (JProperty col in row.Properties())
                {
                    ht.Add(col.Name, col.Value);
                }
                list.Add(ht);
            }

            return list;
        }


        public bool Bean_Add_Update(string Bean_Name, string Gram)
        {
            WebClient client = new WebClient();
            NameValueCollection data = new NameValueCollection();
            client.Headers.Add("user-agent", "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.2; .NET CLR 1.0.3705;)");
            client.Encoding = Encoding.UTF8;

            string url = "http://gdc3.gudi.kr:49001/" + "Bean_Add_Update";
            string method = "POST";

            data.Add("_Bean_Name", Bean_Name);
            data.Add("_Gram", Gram);

            byte[] result = client.UploadValues(url, method, data);
            string strResult = Encoding.UTF8.GetString(result);

            bool success_chk;
            if (strResult == "1")
            {
                success_chk = true;
            }
            else
            {
                success_chk = false;
            }

            return success_chk;
        }

        public bool Form4_Product_Update(string _Product_Number)
        {
            WebClient client = new WebClient();
            NameValueCollection data = new NameValueCollection();
            client.Headers.Add("user-agent", "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.2; .NET CLR 1.0.3705;)");
            client.Encoding = Encoding.UTF8;

            string url = "http://gdc3.gudi.kr:49001/" + "Form4_Product_Update";
            string method = "POST";

            data.Add("_Product_Number", _Product_Number);

            byte[] result = client.UploadValues(url, method, data);
            string strResult = Encoding.UTF8.GetString(result);

            bool success_chk;
            if (strResult == "1")
            {
                success_chk = true;
            }
            else
            {
                success_chk = false;
            }

            return success_chk;
        }
    }
}
