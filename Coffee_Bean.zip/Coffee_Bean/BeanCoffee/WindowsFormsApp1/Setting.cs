﻿using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WindowsFormsApp;

namespace WindowsFormsApp1
{
    public partial class Setting : Form
    {
        Form2 form;
        public Setting(Form2 form)
        {
            InitializeComponent();
            Load += Setting_Load;
            this.form = form;
        }
        
        ComboBox combo1, combo2;
        TextBox Tb1, Tb2, Tb3, Tb4 = new TextBox();
        int sX = 800, sY = 800; // 폼 사이즈 지정.
        string Machine_Number = "";
        string Bean_Number = "";

        private void Setting_Load(object sender, EventArgs e)
        {
            this.Region = Region.FromHrgn(COMMON_Create_Ctl.CreateRoundRectRgn(2, 2, sX, sY, 15, 15));
            this.BackColor = Color.FromArgb(163, 127, 74);
            //FormBorderStyle = FormBorderStyle.None;//폼 상단 표시줄 제거
            this.StartPosition = FormStartPosition.CenterParent;
            COMMON_Create_Ctl comm = new COMMON_Create_Ctl();
            ClientSize = new Size(sX, sY);  // 폼 사이즈 지정.
            //FormBorderStyle = FormBorderStyle.None;// 폼 상단 표시줄 제거
            this.BackColor = Color.FromArgb(255, 205, 66); //백컬러

            LBclass lb1 = new LBclass(this, "label1", "label_name~", 24, 100, 100, 10, 10);
            ArrayList lbarray = new ArrayList();
            lbarray.Add(new LBclass(this, "원두", "원두 :", 15, 100, 40, 50, 50));
            lbarray.Add(new LBclass(this, "용량", "용량(단위KG) :", 15, 250, 40, 50, 120));
            lbarray.Add(new LBclass(this, "온도", "로스팅 온도 :", 15, 250, 40, 50, 190));
            lbarray.Add(new LBclass(this, "시간", "로스팅 시간 :", 15, 250, 40, 50, 240+20));
            lbarray.Add(new LBclass(this, "숙성", "숙성 기간 :", 15, 250, 40, 50, 290+40));
            lbarray.Add(new LBclass(this, "머신", "머신 :", 15, 250, 40, 50, 400));
            for (int i = 0; i < lbarray.Count; i++)
            {

                Label lb = comm.lb((LBclass)lbarray[i]);

                lb.Font = new Font("견명조", 25F, FontStyle.Bold, GraphicsUnit.Point, ((byte)(129)));



                this.Controls.Add(lb);
            }

            ArrayList btnArray = new ArrayList();
            btnArray.Add(new BTNclass(this, "완료", "완료", 100, 100, 500, 650, btn1_Click));
            btnArray.Add(new BTNclass(this, "취소", "취소", 100, 100, 650, 650, btn2_Click));

            for (int i = 0; i < btnArray.Count; i++)
            {
                Button btn = comm.btn((BTNclass)btnArray[i]);

                if (btn.Name == "완료")
                {
                    btn.Font = new Font("견명조", 20F, FontStyle.Bold, GraphicsUnit.Point, ((byte)(129)));  // FontStyle.Regular
                    btn.FlatStyle = FlatStyle.Flat;
                    btn.ForeColor = Color.White;
                    btn.Region = Region.FromHrgn(COMMON_Create_Ctl.CreateRoundRectRgn(2, 2, btn.Width, btn.Height, 15, 15));
                    btn.BackColor = Color.FromArgb(52, 152, 219);  // rgb(218,234,244)
                }
                else if (btn.Name == "취소")
                {
                    btn.Font = new Font("견명조", 20F, FontStyle.Bold, GraphicsUnit.Point, ((byte)(129)));  // FontStyle.Regular
                    btn.FlatStyle = FlatStyle.Flat;
                    btn.ForeColor = Color.White;
                    btn.Region = Region.FromHrgn(COMMON_Create_Ctl.CreateRoundRectRgn(2, 2, btn.Width, btn.Height, 15, 15));
                    btn.BackColor = Color.FromArgb(52, 152, 219);  // rgb(218,234,244)
                }
                this.Controls.Add(btn);
            }

            // 콤보박스==========================================================
            ArrayList Muchine_list = new ArrayList();

            ArrayList ComboArry = Select_Webapi("Form2_Machine_Name_all_Select"); 
            foreach (Hashtable ht in ComboArry)
            {
                Muchine_list.Add(ht["Machine_Name"].ToString());
            }

            combo1 = new ComboBox();
            combo1.Size = new Size(300, 300);
            combo1.Location = new Point(300, 400);
            combo1.Name = "콤보1";
            combo1.SelectedIndexChanged += Combo1_SelectedIndexChanged;
            combo1.Font = new Font(combo1.Font.Name, 27, FontStyle.Regular);
            combo1.DropDownStyle = ComboBoxStyle.DropDownList;
            for (int i = 0; i < Muchine_list.Count; i++)
            {
                combo1.Items.Add(Muchine_list[i]);
            }
            Controls.Add(combo1);

            ArrayList Bean_list = new ArrayList();

            ArrayList ComboArry2 = Select_Webapi("Form2_Bean_Name_all_Select");
            foreach (Hashtable ht in ComboArry2)
            {
                Bean_list.Add(ht["Bean_Name"].ToString());
            }

            combo2 = new ComboBox();
            combo2.Size = new Size(300, 300);
            combo2.Location = new Point(300, 50);
            combo2.Name = "콤보2";
            combo2.SelectedIndexChanged += Combo2_SelectedIndexChanged;
            combo2.Font = new Font(combo1.Font.Name, 27, FontStyle.Regular);
            combo2.DropDownStyle = ComboBoxStyle.DropDownList;
            for (int i = 0; i < Bean_list.Count; i++)
            {
                combo2.Items.Add(Bean_list[i]);
            }
            Controls.Add(combo2);

            //텍스트 박스 ========================================================
            Tb1 = comm.txtbox(new TXTBOXclass(this, "용량", "20", 150, 40, 300, 120, Tb_click));
            Tb2 = comm.txtbox(new TXTBOXclass(this, "온도", "240", 150, 40, 300, 190 - 1, Tb_click));
            Tb3 = comm.txtbox(new TXTBOXclass(this, "시간", "6", 150, 40, 300, 260 - 1, Tb_click));
            Tb4 = comm.txtbox(new TXTBOXclass(this, "숙성", "72", 150, 40, 300, 330 - 1, Tb_click));
            Tb1.Font = new Font(combo1.Font.Name, 27, FontStyle.Regular);
            Tb2.Font = new Font(combo1.Font.Name, 27, FontStyle.Regular);
            Tb3.Font = new Font(combo1.Font.Name, 27, FontStyle.Regular);
            Tb4.Font = new Font(combo1.Font.Name, 27, FontStyle.Regular);
            Controls.Add(Tb1);
            Controls.Add(Tb2);
            Controls.Add(Tb3);
            Controls.Add(Tb4);
        }

        private void Tb_click(object sender, EventArgs e)
        {
            
        }

        private void Combo2_SelectedIndexChanged(object sender, EventArgs e)
        {
           

            foreach (Hashtable ht in Bean_Number_Select(combo2.Text))
            {
                Bean_Number = (ht["Bean_Number"].ToString());

            }
        }

        private void Combo1_SelectedIndexChanged(object sender, EventArgs e)
        {
            foreach (Hashtable ht in Machine_Number_Select(combo1.Text))
            {
                Machine_Number = (ht["Machine_Number"].ToString());

            }
        }

        private void btn1_Click(object sender, EventArgs e)
        {
            string Yn="";
            foreach (Hashtable ht in Form2_Fs_Check_all_Select(Machine_Number))
            {
                Yn = (ht["Fs_Check"].ToString());

            }
            if (Yn == "N")
            {
                Seting_Insert(Bean_Number, Tb1.Text, Machine_Number, Tb3.Text);
            }
            else MessageBox.Show("이미 사용중인 머신입니다.");
            
            form.List_Views();

        }

        private void btn2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        

        public ArrayList Select_Webapi(string controll_name)//셀렉트
        {
            WebClient client = new WebClient();
            //NameValueCollection data = new NameValueCollection();
            client.Headers.Add("user-agent", "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.2; .NET CLR 1.0.3705;)");
            client.Encoding = Encoding.UTF8;    //한글처리

            string url = "http://gdc3.gudi.kr:49001/" + controll_name;
            Stream result = client.OpenRead(url);

            StreamReader sr = new StreamReader(result);
            string str = sr.ReadToEnd();

            ArrayList jList = JsonConvert.DeserializeObject<ArrayList>(str);
            ArrayList list = new ArrayList();
            foreach (JObject row in jList)
            {
                Hashtable ht = new Hashtable();
                foreach (JProperty col in row.Properties())
                {
                    ht.Add(col.Name, col.Value);
                }
                list.Add(ht);
            }

            return list;
        }

        public bool Seting_Insert(string Bean_Number,string Gram,string Machine_Number,string Setting_Time)
        {
            WebClient client = new WebClient();
            NameValueCollection data = new NameValueCollection();
            client.Headers.Add("user-agent", "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.2; .NET CLR 1.0.3705;)");
            client.Encoding = Encoding.UTF8;

            string url = "http://gdc3.gudi.kr:49001/" + "Seting_Insert";
            string method = "POST";

            data.Add("_Bean_Number", Bean_Number);
            data.Add("_Gram", Gram);
            data.Add("_Machine_Number", Machine_Number);
            data.Add("_Setting_Time", Setting_Time);

            byte[] result = client.UploadValues(url, method, data);
            string strResult = Encoding.UTF8.GetString(result);

            bool success_chk;
            if (strResult == "1")
            {
                success_chk = true;
            }
            else
            {
                success_chk = false;
            }

            return success_chk;
        }
        public ArrayList Bean_Number_Select(string _Bean_Name)
        {
            WebClient client = new WebClient();
            NameValueCollection data = new NameValueCollection();
            client.Headers.Add("user-agent", "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.2; .NET CLR 1.0.3705;)");
            client.Encoding = Encoding.UTF8;

            string url = "http://gdc3.gudi.kr:49001/" + "Bean_Number_Select";
            string method = "POST";

            data.Add("_Bean_Name", _Bean_Name);

            byte[] result = client.UploadValues(url, method, data);
            string strResult = Encoding.UTF8.GetString(result);

            ArrayList jList = JsonConvert.DeserializeObject<ArrayList>(strResult);
            ArrayList list = new ArrayList();
            foreach (JObject row in jList)
            {
                Hashtable ht = new Hashtable();
                foreach (JProperty col in row.Properties())
                {
                    ht.Add(col.Name, col.Value);
                }
                list.Add(ht);
            }

            return list;

        }

        public ArrayList Machine_Number_Select(string _Machine_Name)
        {
            WebClient client = new WebClient();
            NameValueCollection data = new NameValueCollection();
            client.Headers.Add("user-agent", "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.2; .NET CLR 1.0.3705;)");
            client.Encoding = Encoding.UTF8;

            string url = "http://gdc3.gudi.kr:49001/" + "Machine_Number_Select";
            string method = "POST";

            data.Add("_Machine_Name", _Machine_Name);

            byte[] result = client.UploadValues(url, method, data);
            string strResult = Encoding.UTF8.GetString(result);

            ArrayList jList = JsonConvert.DeserializeObject<ArrayList>(strResult);
            ArrayList list = new ArrayList();
            foreach (JObject row in jList)
            {
                Hashtable ht = new Hashtable();
                foreach (JProperty col in row.Properties())
                {
                    ht.Add(col.Name, col.Value);
                }
                list.Add(ht);
            }

            return list;

        }

        public ArrayList Form2_Fs_Check_all_Select(string _Machine_Number)
        {
            WebClient client = new WebClient();
            NameValueCollection data = new NameValueCollection();
            client.Headers.Add("user-agent", "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.2; .NET CLR 1.0.3705;)");
            client.Encoding = Encoding.UTF8;

            string url = "http://gdc3.gudi.kr:49001/" + "Form2_Fs_Check_all_Select";
            string method = "POST";

            data.Add("_Machine_Number", _Machine_Number);

            byte[] result = client.UploadValues(url, method, data);
            string strResult = Encoding.UTF8.GetString(result);

            ArrayList jList = JsonConvert.DeserializeObject<ArrayList>(strResult);
            ArrayList list = new ArrayList();
            foreach (JObject row in jList)
            {
                Hashtable ht = new Hashtable();
                foreach (JProperty col in row.Properties())
                {
                    ht.Add(col.Name, col.Value);
                }
                list.Add(ht);
            }

            return list;

        }
    }
}
