﻿using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WindowsFormsApp;

namespace WindowsFormsApp1
{
    public partial class Bean_add : Form
    {
        public Bean_add()
        {
            InitializeComponent();
            Load += Bean_add_Load;
        }
        ComboBox combo1, combo2;
        TextBox Tb1, Tb2, Tb3, Tb4 = new TextBox();
        int sX = 800, sY = 800; // 폼 사이즈 지정.
        private void Bean_add_Load(object sender, EventArgs e)
        {
            this.Region = Region.FromHrgn(COMMON_Create_Ctl.CreateRoundRectRgn(2, 2, sX, sY, 15, 15));
            this.BackColor = Color.FromArgb(163, 127, 74);
            FormBorderStyle = FormBorderStyle.None; //폼 상단 표시줄 제거
            this.StartPosition = FormStartPosition.CenterParent;
            COMMON_Create_Ctl comm = new COMMON_Create_Ctl();
            ClientSize = new Size(sX, sY);  // 폼 사이즈 지정.
            //FormBorderStyle = FormBorderStyle.None;// 폼 상단 표시줄 제거
            this.BackColor = Color.FromArgb(255, 205, 66); //백컬러
            //
            LBclass lb1 = new LBclass(this, "label1", "label_name~", 24, 100, 100, 10, 10);
            ArrayList lbarray = new ArrayList();
            lbarray.Add(new LBclass(this, "원두", "원두 :", 15, 100, 40, 50, 50));
            lbarray.Add(new LBclass(this, "용량", "용량(단위KG) :", 15, 250, 40, 50, 120));

            for (int i = 0; i < lbarray.Count; i++)
            {

                Label lb = comm.lb((LBclass)lbarray[i]);

                lb.Font = new Font("견명조", 25F, FontStyle.Bold, GraphicsUnit.Point, ((byte)(129)));

                this.Controls.Add(lb);
            }

            ArrayList Bean_list = new ArrayList();

            

            ArrayList ComboArry2 = Select_Webapi("Form2_Bean_Name_all_Select");
            foreach (Hashtable ht in ComboArry2)
            {
                Bean_list.Add(ht["Bean_Name"].ToString());
            }

            combo2 = new ComboBox();
            combo2.Size = new Size(300, 300);
            combo2.Location = new Point(300, 50);
            combo2.Name = "콤보2";
            combo2.SelectedIndexChanged += Combo2_SelectedIndexChanged;
            combo2.Font = new Font(combo2.Font.Name, 27, FontStyle.Regular);
            combo2.DropDownStyle = ComboBoxStyle.DropDownList;
            for (int i = 0; i < Bean_list.Count; i++)
            {
                combo2.Items.Add(Bean_list[i]);
            }
            Controls.Add(combo2);

            Tb1 = comm.txtbox(new TXTBOXclass(this, "용량", "20", 150, 40, 300, 120, Tb_click));
            Tb1.Font = new Font(combo2.Font.Name, 27, FontStyle.Regular);
            Controls.Add(Tb1);

            ArrayList btnArray = new ArrayList();
            btnArray.Add(new BTNclass(this, "완료", "완료", 100, 100, 500, 650, btn1_Click));
            btnArray.Add(new BTNclass(this, "취소", "취소", 100, 100, 650, 650, btn2_Click));

            for (int i = 0; i < btnArray.Count; i++)
            {
                Button btn = comm.btn((BTNclass)btnArray[i]);

                if (btn.Name == "완료")
                {
                    btn.Font = new Font("견명조", 20F, FontStyle.Bold, GraphicsUnit.Point, ((byte)(129)));  // FontStyle.Regular
                    btn.FlatStyle = FlatStyle.Flat;
                    btn.ForeColor = Color.White;
                    btn.Region = Region.FromHrgn(COMMON_Create_Ctl.CreateRoundRectRgn(2, 2, btn.Width, btn.Height, 15, 15));
                    btn.BackColor = Color.FromArgb(52, 152, 219);  // rgb(218,234,244)
                }
                else if (btn.Name == "취소")
                {
                    btn.Font = new Font("견명조", 20F, FontStyle.Bold, GraphicsUnit.Point, ((byte)(129)));  // FontStyle.Regular
                    btn.FlatStyle = FlatStyle.Flat;
                    btn.ForeColor = Color.White;
                    btn.Region = Region.FromHrgn(COMMON_Create_Ctl.CreateRoundRectRgn(2, 2, btn.Width, btn.Height, 15, 15));
                    btn.BackColor = Color.FromArgb(52, 152, 219);  // rgb(218,234,244)
                }
                this.Controls.Add(btn);
            }
        }

        private void btn1_Click(object sender, EventArgs e)
        {

            if(Bean_Add_Update(combo2.Text, Tb1.Text))
            {
                MessageBox.Show("입고 완료");
                MessageBox.Show(combo2.Text);
                MessageBox.Show(Tb1.Text);
            }
            else
            {
                MessageBox.Show("입고 오류");
            }

        }

        private void btn2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Tb_click(object sender, EventArgs e)
        {
            
        }

        private void Combo2_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }

        public ArrayList Select_Webapi(string controll_name)//셀렉트
        {
            WebClient client = new WebClient();
            //NameValueCollection data = new NameValueCollection();
            client.Headers.Add("user-agent", "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.2; .NET CLR 1.0.3705;)");
            client.Encoding = Encoding.UTF8;    //한글처리

            string url = "http://gdc3.gudi.kr:49001/" + controll_name;
            Stream result = client.OpenRead(url);

            StreamReader sr = new StreamReader(result);
            string str = sr.ReadToEnd();

            ArrayList jList = JsonConvert.DeserializeObject<ArrayList>(str);
            ArrayList list = new ArrayList();
            foreach (JObject row in jList)
            {
                Hashtable ht = new Hashtable();
                foreach (JProperty col in row.Properties())
                {
                    ht.Add(col.Name, col.Value);
                }
                list.Add(ht);
            }

            return list;
        }


        public bool Bean_Add_Update(string Bean_Name, string Gram)
        {
            WebClient client = new WebClient();
            NameValueCollection data = new NameValueCollection();
            client.Headers.Add("user-agent", "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.2; .NET CLR 1.0.3705;)");
            client.Encoding = Encoding.UTF8;

            string url = "http://gdc3.gudi.kr:49001/" + "Bean_Add_Update";
            string method = "POST";

            data.Add("_Bean_Name", Bean_Name);
            data.Add("_Gram", Gram);

            byte[] result = client.UploadValues(url, method, data);
            string strResult = Encoding.UTF8.GetString(result);

            bool success_chk;
            if (strResult == "1")
            {
                success_chk = true;
            }
            else
            {
                success_chk = false;
            }

            return success_chk;
        }
    }
}
