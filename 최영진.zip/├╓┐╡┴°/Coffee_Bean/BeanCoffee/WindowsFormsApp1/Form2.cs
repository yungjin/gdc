﻿using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;
using WindowsFormsApp;

namespace WindowsFormsApp1
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
            Load += Form2_Load;
        }

        private JObject param;
        private ListView lv;
        private LISTVIEWclass lv_value;
        private COMMON_Create_Ctl comm;
        private Chart chart2;
        private Panel panel1;
        private string Machine_Number= "";
        private void Form2_Load(object sender, EventArgs e)
        {
            this.FormBorderStyle = FormBorderStyle.None;// 폼 상단 표시줄 제거
            this.Dock = DockStyle.Fill; //판넬크기에 맞게 사이즈 늘림.
            comm = new COMMON_Create_Ctl();
            this.BackColor = Color.FromArgb(163, 127, 74);// 폼 백컬러

            //판넬
            panel1 = new Panel();
            panel1.BackColor = Color.FromArgb(237, 227, 183);
            panel1.Size = new Size(1170, 700);
            panel1.Location = new Point(50, 50);
            panel1.Region = Region.FromHrgn(COMMON_Create_Ctl.CreateRoundRectRgn(2, 2, panel1.Width, panel1.Height, 15, 15));

            lv_value = new LISTVIEWclass(this, "ListView1", 1060, 350, 50, 50, listView_MouseClick, null, 12, "", 0, "머신", 110, "원두", 180, "용량", 90, "온도", 100, "설정 시간", 140, "결점두 확인", 0, "로스팅 완료 시간", 300, "숙성 기간", 150, "", 0, "", 0, "", 0);
            lv = comm.listView(lv_value);
            panel1.Controls.Add(lv);
            lv.Font = new Font("Arial", 18, FontStyle.Bold);
            List_Views();

            //panel1.Controls.Add(textBox1);
            // 콤보박스==========================================================
            ArrayList Muchine_list = new ArrayList();
            Muchine_list.Add("머신1");
            Muchine_list.Add("머신2");
            Muchine_list.Add("머신3");

            //남은 시간 ============================================================
            //차트그래프
            chart2 = new Chart();

            ChartArea chartArea2 = new ChartArea();
            Legend legend2 = new Legend();
            Series series2 = new Series();

            chartArea2.Name = "ChartArea2";
            legend2.Name = "Legend2";
            series2.ChartArea = "ChartArea2";
            series2.ChartType = SeriesChartType.Doughnut;
            series2.Legend = "Legend2";
            series2.Name = "Series2";
            chartArea2.BackColor = Color.FromArgb(237, 227, 183);// 배경색상
            legend2.BackColor = Color.FromArgb(237, 227, 183);// 배경색상

            chart2.Name = "chart2";
            chart2.Size = new Size(310, 310);
            chart2.Location = new Point(80, 400);
            chart2.Text = "chart2";
            chart2.ChartAreas.Add(chartArea2);
            chart2.Legends.Add(legend2);
            chart2.Series.Add(series2);
            chart2.BackColor = Color.FromArgb(237, 227, 183);

            ArrayList arry1 = Select_Webapi("Form1_Chart_Roasting_select");
            chart2.Series["Series2"].IsValueShownAsLabel = true;
            foreach (Hashtable ht in arry1) // 이름 , 그램 차트그래프 데이터 삽입 
            {
                chart2.Series["Series2"].Points.AddXY(ht["col1"].ToString(), ht["col2"].ToString());

            }

            panel1.Controls.Add(chart2);

            //버튼 =================================================================
            ArrayList btnArray = new ArrayList();
            btnArray.Add(new BTNclass(this, "설정", "설 정", 200, 200, 480, 450, btn1_Click));
            btnArray.Add(new BTNclass(this, "결점두 확인", "결점두 확인", 400, 200, 710, 450, btn2_Click));

            for (int i = 0; i < btnArray.Count; i++)
            {
                Button btn = comm.btn((BTNclass)btnArray[i]);

                if (btn.Name == "설정")
                {
                    btn.Font = new Font("견명조", 20F, FontStyle.Bold, GraphicsUnit.Point, ((byte)(129)));  // FontStyle.Regular
                    btn.FlatStyle = FlatStyle.Flat;
                    btn.ForeColor = Color.White;
                    btn.BackColor = Color.FromArgb(80, 200, 223);
                    btn.Region = Region.FromHrgn(COMMON_Create_Ctl.CreateRoundRectRgn(2, 2, btn.Width, btn.Height, 15, 15));
                    btn.BackColor = Color.FromArgb(52, 152, 219);  // rgb(218,234,244)
                }
                else if (btn.Name == "결점두 확인")
                {
                    btn.Font = new Font("견명조", 20F, FontStyle.Bold, GraphicsUnit.Point, ((byte)(129)));  // FontStyle.Regular
                    btn.FlatStyle = FlatStyle.Flat;
                    btn.ForeColor = Color.White;
                    btn.BackColor = Color.FromArgb(80, 200, 223);
                    btn.Region = Region.FromHrgn(COMMON_Create_Ctl.CreateRoundRectRgn(2, 2, btn.Width, btn.Height, 15, 15));
                    btn.BackColor = Color.FromArgb(218, 234, 244);  // rgb(218,234,244)
                    btn.Enabled = false;
                }
                panel1.Controls.Add(btn);
            }
            this.Controls.Add(panel1);
        }        
        private void listView_MouseClick(object sender, MouseEventArgs e)
        {
            Control btn = null;
            param = new JObject();
            foreach (Control ctr in panel1.Controls)
            {
                if (ctr.Name == "결점두 확인")
                {
                    btn = ctr;
                }
            }
            ListView lView = (ListView)sender;
            ListViewItem item = lView.SelectedItems[0];
            if (Convert.ToInt32(item.SubItems[0].Text) < 0)
            {
                btn.Enabled = false;
                btn.BackColor = Color.FromArgb(218, 234, 244);
            }
            else
            {
                btn.Enabled = true;
                btn.BackColor = Color.FromArgb(52, 152, 219);
                param.Add("_Roasting_Gram", item.SubItems[3].Text);
                param.Add("_Bean_Number", item.SubItems[9].Text);
                param.Add("_Roasting_Number", item.SubItems[10].Text);
                param.Add("_Machine_Number", item.SubItems[11].Text);
                MessageBox.Show(param.ToString());
            }

        }
        private void btn1_Click(object sender, EventArgs e)
        {
            new Setting(this).ShowDialog();
        }
        private void btn2_Click(object sender, EventArgs e)
        {
            Control btn = null;
            foreach (Control ctr in panel1.Controls)
            {
                if (ctr.Name == "결점두 확인")
                {
                    btn = ctr;
                }
            }
            ArrayList arry = Select_Params_Webapi("Form2_FS_Check", param.ToString());
            foreach (JArray aRow in arry)
            {
                if(aRow[0].ToString() == "1")
                {
                    MessageBox.Show("성공");
                    btn.Enabled = false;
                    btn.BackColor = Color.FromArgb(218, 234, 244);
                    List_Views();
                }
                else
                {
                    MessageBox.Show("실패");
                }
            }            
        }

        public void List_Views()//리스트뷰 셀렉트
        {
            string Fs = "";
            lv.Items.Clear();
            ArrayList arry = Select_Webapi("Form2_Roasting_all_Select_2");
            foreach (Hashtable ht in arry)
            {
                ListViewItem item = new ListViewItem(ht["비교"].ToString());
                item.SubItems.Add(ht["머신"].ToString());
                item.SubItems.Add(ht["원두명"].ToString());
                item.SubItems.Add(ht["로스팅그램"].ToString());
                item.SubItems.Add(ht["로스팅온도"].ToString());
                item.SubItems.Add(ht["설정시간"].ToString());
                Fs = ht["결점두체크"].ToString();
                if (Fs == "Y")
                {
                    item.SubItems.Add("확인요망");
                }
                else
                {
                    item.SubItems.Add("-");
                }
                item.SubItems.Add(ht["로스팅완료시간"].ToString());
                item.SubItems.Add(ht["숙성시간"].ToString());

                item.SubItems.Add(ht["Bean_Number"].ToString());
                item.SubItems.Add(ht["Roasting_Number"].ToString());
                item.SubItems.Add(ht["Machine_Number"].ToString());

                lv.Items.Add(item);
            }

            panel1.Controls.Add(lv);

        }
        public ArrayList Select_Webapi(string controll_name)
        {
            WebClient client = new WebClient();
            //NameValueCollection data = new NameValueCollection();
            client.Headers.Add("user-agent", "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.2; .NET CLR 1.0.3705;)");
            client.Encoding = Encoding.UTF8;    //한글처리

            string url = "http://gdc3.gudi.kr:49001/" + controll_name;
            Stream result = client.OpenRead(url);

            StreamReader sr = new StreamReader(result);
            string str = sr.ReadToEnd();

            ArrayList jList = JsonConvert.DeserializeObject<ArrayList>(str);
            ArrayList list = new ArrayList();
            foreach (JObject row in jList)
            {
                Hashtable ht = new Hashtable();
                foreach (JProperty col in row.Properties())
                {
                    ht.Add(col.Name, col.Value);
                }
                list.Add(ht);
            }

            return list;
        }
        public bool Form2_FS_Check(string _Machine_Number,string _Roasting_Number, string _Bean_Number, string _Roasting_Gram)
        {
            WebClient client = new WebClient();
            NameValueCollection data = new NameValueCollection();
            client.Headers.Add("user-agent", "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.2; .NET CLR 1.0.3705;)");
            client.Encoding = Encoding.UTF8;

            string url = "http://gdc3.gudi.kr:49001/" + "Form2_FS_Check";
            string method = "POST";

            data.Add("_Machine_Number", _Machine_Number);
            data.Add("_Roasting_Number", _Roasting_Number);
            data.Add("_Bean_Number", _Bean_Number);
            data.Add("_Roasting_Gram", _Roasting_Gram);

            byte[] result = client.UploadValues(url, method, data);
            string strResult = Encoding.UTF8.GetString(result);

            bool success_chk;
            if (strResult == "1")
            {
                success_chk = true;
            }
            else
            {
                success_chk = false;
            }

            return success_chk;
        }
        public ArrayList Machine_Number_Select(string _Machine_Name)
        {
            WebClient client = new WebClient();
            NameValueCollection data = new NameValueCollection();
            client.Headers.Add("user-agent", "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.2; .NET CLR 1.0.3705;)");
            client.Encoding = Encoding.UTF8;

            string url = "http://gdc3.gudi.kr:49001/" + "Machine_Number_Select";
            string method = "POST";

            data.Add("_Machine_Name", _Machine_Name);

            byte[] result = client.UploadValues(url, method, data);
            string strResult = Encoding.UTF8.GetString(result);

            ArrayList jList = JsonConvert.DeserializeObject<ArrayList>(strResult);
            ArrayList list = new ArrayList();
            foreach (JObject row in jList)
            {
                Hashtable ht = new Hashtable();
                foreach (JProperty col in row.Properties())
                {
                    ht.Add(col.Name, col.Value);
                }
                list.Add(ht);
            }

            return list;

        }
        public ArrayList Form2_Date_slect(string _Machine_Number)
        {
            WebClient client = new WebClient();
            NameValueCollection data = new NameValueCollection();
            client.Headers.Add("user-agent", "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.2; .NET CLR 1.0.3705;)");
            client.Encoding = Encoding.UTF8;

            string url = "http://gdc3.gudi.kr:49001/" + "Form2_Date_slect";
            string method = "POST";

            data.Add("_Machine_Number", _Machine_Number);

            byte[] result = client.UploadValues(url, method, data);
            string strResult = Encoding.UTF8.GetString(result);

            ArrayList jList = JsonConvert.DeserializeObject<ArrayList>(strResult);
            ArrayList list = new ArrayList();
            foreach (JObject row in jList)
            {
                Hashtable ht = new Hashtable();
                foreach (JProperty col in row.Properties())
                {
                    ht.Add(col.Name, col.Value);
                }
                list.Add(ht);
            }

            return list;

        }

        public ArrayList Select_Params_Webapi(string sql, string param)
        {
            WebClient client = new WebClient();
            NameValueCollection data = new NameValueCollection();
            client.Headers.Add("user-agent", "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.2; .NET CLR 1.0.3705;)");
            client.Encoding = Encoding.UTF8;

            string url = "http://gdc3.gudi.kr:49001/" + "Select_Params";
            string method = "POST";

            data.Add("CommandText", sql);
            data.Add("ParamMap", param);

            byte[] result = client.UploadValues(url, method, data);
            string strResult = Encoding.UTF8.GetString(result);
            return JsonConvert.DeserializeObject<ArrayList>(strResult);
        }
    }
}
