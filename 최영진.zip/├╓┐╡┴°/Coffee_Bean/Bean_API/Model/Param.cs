﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Bean_API.Model
{
    public class Param
    {
        public string CommandText { set; get; }
        public string ParamMap { set; get; }
    }
}
