-- --------------------------------------------------------
-- 호스트:                          192.168.3.139
-- 서버 버전:                        10.1.37-MariaDB - MariaDB Server
-- 서버 OS:                        Linux
-- HeidiSQL 버전:                  9.5.0.5295
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

-- 테이블 coffee.Bean 구조 내보내기
CREATE TABLE IF NOT EXISTS `Bean` (
  `Bean_Number` int(11) NOT NULL AUTO_INCREMENT,
  `Bean_Name` varchar(100) NOT NULL,
  `Country` varchar(100) NOT NULL,
  `Gram` int(11) NOT NULL,
  `Receving_Date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`Bean_Number`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

-- 테이블 데이터 coffee.Bean:~6 rows (대략적) 내보내기
DELETE FROM `Bean`;
/*!40000 ALTER TABLE `Bean` DISABLE KEYS */;
INSERT INTO `Bean` (`Bean_Number`, `Bean_Name`, `Country`, `Gram`, `Receving_Date`) VALUES
	(1, '케냐 AA', '케냐', 70, '2019-02-26 15:08:13'),
	(2, '하와이안 코나', '하와이', 10, '2019-02-26 15:08:13'),
	(3, '예가체프', '에티오피아', 50, '2019-02-26 15:08:13'),
	(4, '코피 루왁', '인도네시아', 50, '2019-02-26 15:08:13'),
	(5, '예멘모카', '예멘', 115, '2019-02-26 15:08:13'),
	(6, '블루마운틴', '자메이카', 80, '2019-02-26 15:08:13');
/*!40000 ALTER TABLE `Bean` ENABLE KEYS */;

-- 프로시저 coffee.Bean_Add_Update 구조 내보내기
DELIMITER //
CREATE DEFINER=`root`@`%` PROCEDURE `Bean_Add_Update`( IN _Bean_Name VARCHAR(255),IN _Gram VARCHAR(255))
BEGIN

UPDATE Bean SET Gram = Gram+_Gram WHERE Bean_Name = _Bean_Name;

END//
DELIMITER ;

-- 프로시저 coffee.Bean_Number_Select 구조 내보내기
DELIMITER //
CREATE DEFINER=`root`@`%` PROCEDURE `Bean_Number_Select`( in _Bean_Name VARCHAR(255))
BEGIN

SELECT Bean_Number FROM Bean WHERE Bean_Name = _Bean_Name;

END//
DELIMITER ;

-- 프로시저 coffee.Form1_Chart_all_Select 구조 내보내기
DELIMITER //
CREATE DEFINER=`root`@`%` PROCEDURE `Form1_Chart_all_Select`()
BEGIN
	
select Bean_Name as col1, Gram as col2 from Bean;

END//
DELIMITER ;

-- 프로시저 coffee.Form1_Chart_Bean_select 구조 내보내기
DELIMITER //
CREATE DEFINER=`root`@`%` PROCEDURE `Form1_Chart_Bean_select`()
BEGIN

SELECT b.Bean_Name as col1,
case when b.Bean_Number=r.Bean_Number and b.Bean_Number=p.Bean_Number
	  then (r.rg+p.pg)-b.Gram
	  when b.Bean_Number=r.Bean_Number
	  then b.Gram-r.rg
	  when b.Bean_Number=p.Bean_Number
	  then b.Gram-p.pg
	  ELSE b.Gram
	  END AS col2
FROM Bean b
LEFT OUTER JOIN (SELECT Bean_Number, SUM(Product_Gram) AS pg FROM Product GROUP BY Bean_Number) AS p
ON (b.Bean_Number = p.Bean_Number)
LEFT OUTER JOIN (SELECT Bean_Number, SUM(Roasting_Gram) AS rg FROM Roasting WHERE Roasting_Check = 'N' GROUP BY Bean_Number) AS r
ON (b.Bean_Number = r.Bean_Number)
GROUP BY b.Bean_Name
order BY b.Bean_Number;

END//
DELIMITER ;

-- 프로시저 coffee.Form1_Chart_Product_select 구조 내보내기
DELIMITER //
CREATE DEFINER=`root`@`%` PROCEDURE `Form1_Chart_Product_select`()
BEGIN

SELECT d.Bean_Name as col1,SUM(Product_Gram) as col2
FROM Product s JOIN Bean d ON s.Bean_Number = d.Bean_Number GROUP BY Bean_Name;

END//
DELIMITER ;

-- 프로시저 coffee.Form1_Chart_Roasting_select 구조 내보내기
DELIMITER //
CREATE DEFINER=`root`@`%` PROCEDURE `Form1_Chart_Roasting_select`()
BEGIN

SELECT d.Bean_Name as col1, SUM(Roasting_Gram) as col2
FROM Roasting s JOIN Bean d ON s.Bean_Number = d.Bean_Number where s.Roasting_Check = 'N' GROUP BY Bean_Name;

END//
DELIMITER ;

-- 프로시저 coffee.Form2_Bean_Name_all_Select 구조 내보내기
DELIMITER //
CREATE DEFINER=`root`@`%` PROCEDURE `Form2_Bean_Name_all_Select`()
BEGIN

SELECT Bean_Name FROM Bean;

END//
DELIMITER ;

-- 프로시저 coffee.Form2_Date_slect 구조 내보내기
DELIMITER //
CREATE DEFINER=`root`@`%` PROCEDURE `Form2_Date_slect`(
	IN `_Machine_Number` INT
)
BEGIN

SELECT left(RoastingEnd_Date,16) as '로스팅종료 시간',Roasting_Number as '로스팅번호',Bean_Number as '원두번호',Roasting_Gram AS '로스팅그램'
FROM Roasting WHERE Machine_Number=_Machine_Number 
AND Roasting_check = 'N';

END//
DELIMITER ;

-- 프로시저 coffee.Form2_FS_Check 구조 내보내기
DELIMITER //
CREATE DEFINER=`root`@`%` PROCEDURE `Form2_FS_Check`(
	IN `_Machine_Number` int,
	IN `_Roasting_Number` INT,
	IN `_Bean_Number` INT,
	IN `_Roasting_Gram` INT








)
BEGIN
DECLARE DATE1 DATETIME;
DECLARE DATE2 DATETIME;

set DATE1 = (SELECT RoastingEnd_Date 
              FROM Roasting 
				 WHERE Roasting_Number = _Roasting_Number
               AND Bean_Number = _Bean_Number
             	AND Machine_Number = _Machine_Number);
set DATE2 = (SELECT NOW());

if DATE1 < DATE2 THEN
	UPDATE Roasting SET Roasting_Check = 'Y' 
	 WHERE Roasting_Number = _Roasting_Number
      AND Bean_Number = _Bean_Number
      AND Machine_Number = _Machine_Number;
	
	UPDATE Machine SET Fs_Check = 'N' 
	 WHERE Machine_Number = _Machine_Number;
	
	INSERT INTO Product(Roasting_Number,Bean_Number,Product_Gram,Machine_Number)
	SELECT Roasting_Number,Bean_Number,Roasting_Gram,Machine_Number
	FROM Roasting
	WHERE Roasting_Number = _Roasting_Number
     AND Bean_Number = _Bean_Number
     AND Machine_Number = _Machine_Number;
   select 1 as state;  
ELSE
   select 0 as state;	
END if;

END//
DELIMITER ;

-- 프로시저 coffee.Form2_Fs_Check_all_Select 구조 내보내기
DELIMITER //
CREATE DEFINER=`root`@`%` PROCEDURE `Form2_Fs_Check_all_Select`(in _Machine_Number int)
BEGIN

SELECT Fs_Check FROM Machine WHERE Machine_Number = _Machine_Number; 

END//
DELIMITER ;

-- 프로시저 coffee.Form2_Machine_Name_all_Select 구조 내보내기
DELIMITER //
CREATE DEFINER=`root`@`%` PROCEDURE `Form2_Machine_Name_all_Select`()
BEGIN

SELECT Machine_Number, Machine_Name FROM Machine;

END//
DELIMITER ;

-- 프로시저 coffee.Form2_Roasting_all_Select 구조 내보내기
DELIMITER //
CREATE DEFINER=`root`@`%` PROCEDURE `Form2_Roasting_all_Select`()
BEGIN

SELECT 
Machine_Name AS '머신',
Bean_Name AS'로스팅 원두',
Roasting_Gram AS '로스팅 그램' ,
Roasting_Degree AS '로스팅 온도',
Cooling_Time AS '설정 시간',
Defect_Check AS '결점두 체크',
Ripening_Time AS '숙석 기간',
Roasting_Check AS '로스팅 완료'
from Roasting r
left JOIN Machine m ON r.Machine_Number = m.Machine_Number
left JOIN Bean b ON r.Bean_Number = r.Bean_Number
WHERE Roasting_Check = 'N' 
GROUP BY Machine_Name ;

END//
DELIMITER ;

-- 프로시저 coffee.Form2_Roasting_all_Select_2 구조 내보내기
DELIMITER //
CREATE DEFINER=`root`@`%` PROCEDURE `Form2_Roasting_all_Select_2`()
BEGIN

SELECT tot.*, TIMESTAMPDIFF(SECOND, tot.로스팅완료시간, CURRENT_TIMESTAMP()) AS '비교' 
FROM (
		SELECT 
					b.Bean_Number,
		         r.Roasting_Number,
		         m.Machine_Number,
					m.Machine_Name AS '머신',
					b.Bean_Name AS '원두명',
					r.Roasting_Gram AS '로스팅그램',
					m.Roasting_Degree AS'로스팅온도',
					m.Roasting_Time AS '설정시간',
					m.Defect_Check AS '결점두체크',
					left(r.RoastingEnd_Date,16) AS '로스팅완료시간',
					m.Ripening_Time AS '숙성시간'
		FROM Bean b
		left join Roasting r ON b.Bean_Number = r.Bean_Number
		left join Machine m ON r.Machine_Number = m.Machine_Number
		WHERE Defect_Check = 'N' AND Roasting_Check = 'N'
		) AS tot;

END//
DELIMITER ;

-- 프로시저 coffee.Form2_Solo_Bean_Select 구조 내보내기
DELIMITER //
CREATE DEFINER=`root`@`%` PROCEDURE `Form2_Solo_Bean_Select`( in _Bean_Number int)
BEGIN
SELECT b.*, p.pg, r.rg FROM Bean b
LEFT OUTER JOIN (SELECT Bean_Number, SUM(Product_Gram) AS pg FROM Product GROUP BY Bean_Number) AS p
ON (b.Bean_Number = p.Bean_Number)
LEFT OUTER JOIN (SELECT Bean_Number, SUM(Roasting_Gram) AS rg FROM Roasting WHERE Roasting_Check = 'N' GROUP BY Bean_Number) AS r
ON (b.Bean_Number = r.Bean_Number)
WHERE b.Bean_Number = _Bean_Number
;
END//
DELIMITER ;

-- 프로시저 coffee.Form3_Product_Update 구조 내보내기
DELIMITER //
CREATE DEFINER=`root`@`%` PROCEDURE `Form3_Product_Update`(IN _Product_Number int)
BEGIN	

UPDATE Product SET End_Check = 'Y' Where Product_Number = _Product_Number;
UPDATE Product SET Released_Date = NOW() Where Product_Number = _Product_Number;

END//
DELIMITER ;

-- 프로시저 coffee.Form4_Product_Select 구조 내보내기
DELIMITER //
CREATE DEFINER=`root`@`%` PROCEDURE `Form4_Product_Select`()
BEGIN	

SELECT p.Product_Number AS 번호,
		 b.Bean_Name AS 원두,
		 p.Product_Gram AS 용량,
		 p.Released_Date AS 포장날짜
from Product p
JOIN Bean b ON (b.bean_Number = p.Bean_Number)
WHERE p.End_Check = 'Y';

END//
DELIMITER ;

-- 프로시저 coffee.Form4_Product_Update 구조 내보내기
DELIMITER //
CREATE DEFINER=`root`@`%` PROCEDURE `Form4_Product_Update`(IN _Product_Number int)
BEGIN	

UPDATE Product SET End_Check = 'E' Where Product_Number = _Product_Number;

END//
DELIMITER ;

-- 프로시저 coffee.From3_ 구조 내보내기
DELIMITER //
CREATE DEFINER=`root`@`%` PROCEDURE `From3_`(
	IN `_Machine_Number` int




)
BEGIN
SELECT tot.*, TIMESTAMPDIFF(SECOND, tot.숙성완료시간, CURRENT_TIMESTAMP()) AS '비교' 
  FROM (
			SELECT m.Machine_Number,
					 m.Machine_Name AS '머신',
					 b.Bean_Name AS '원두',
					 p.Product_Gram AS '용량',
					 p.package_Date AS '로스팅 완료 시간',
					 DATE_ADD(p.package_Date, INTERVAL 72 HOUR) AS '숙성완료시간',
					 p.Product_Number
			From Product p 
			LEFT JOIN Machine m ON (m.Machine_Number = p.Machine_Number) 
			left JOIN Bean b ON (p.Bean_Number = b.Bean_Number)
			WHERE m.Machine_Number = _Machine_Number AND p.End_Check = 'N'
		) as tot;
END//
DELIMITER ;

-- 테이블 coffee.Machine 구조 내보내기
CREATE TABLE IF NOT EXISTS `Machine` (
  `Machine_Number` int(11) NOT NULL AUTO_INCREMENT,
  `Machine_Name` varchar(100) NOT NULL,
  `Fs_Check` varchar(100) NOT NULL DEFAULT 'N',
  `Roasting_Degree` varchar(100) NOT NULL,
  `Roasting_Time` varchar(100) NOT NULL,
  `Cooling_Time` varchar(100) NOT NULL,
  `Defect_Check` varchar(10) NOT NULL DEFAULT 'N',
  `Ripening_Time` varchar(100) NOT NULL,
  PRIMARY KEY (`Machine_Number`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- 테이블 데이터 coffee.Machine:~3 rows (대략적) 내보내기
DELETE FROM `Machine`;
/*!40000 ALTER TABLE `Machine` DISABLE KEYS */;
INSERT INTO `Machine` (`Machine_Number`, `Machine_Name`, `Fs_Check`, `Roasting_Degree`, `Roasting_Time`, `Cooling_Time`, `Defect_Check`, `Ripening_Time`) VALUES
	(1, '1머신', 'N', '240', '6', '3', 'N', '72'),
	(2, '2머신', 'N', '240', '6', '3', 'N', '72'),
	(3, '3머신', 'N', '240', '6', '3', 'N', '72');
/*!40000 ALTER TABLE `Machine` ENABLE KEYS */;

-- 프로시저 coffee.Machine_Number_Select 구조 내보내기
DELIMITER //
CREATE DEFINER=`root`@`%` PROCEDURE `Machine_Number_Select`( in _Machine_Name VARCHAR(255))
BEGIN

SELECT Machine_Number FROM Machine WHERE Machine_Name = _Machine_Name;

END//
DELIMITER ;

-- 테이블 coffee.Product 구조 내보내기
CREATE TABLE IF NOT EXISTS `Product` (
  `Product_Number` int(11) NOT NULL AUTO_INCREMENT,
  `Roasting_Number` int(11) NOT NULL,
  `Bean_Number` int(11) NOT NULL,
  `Product_Gram` int(11) NOT NULL DEFAULT '0',
  `package_Date` datetime DEFAULT CURRENT_TIMESTAMP,
  `Released_Date` datetime DEFAULT NULL,
  `Machine_Number` int(11) NOT NULL,
  `End_Check` varchar(50) NOT NULL DEFAULT 'N',
  PRIMARY KEY (`Product_Number`),
  KEY `FK_Product_Bean` (`Bean_Number`),
  KEY `FK_Product_Roasting` (`Roasting_Number`),
  KEY `Fk_Machin_Number` (`Machine_Number`),
  CONSTRAINT `FK_Product_Bean` FOREIGN KEY (`Bean_Number`) REFERENCES `Bean` (`Bean_Number`),
  CONSTRAINT `FK_Product_Roasting` FOREIGN KEY (`Roasting_Number`) REFERENCES `Roasting` (`Roasting_Number`),
  CONSTRAINT `Fk_Machin_Number` FOREIGN KEY (`Machine_Number`) REFERENCES `Machine` (`Machine_Number`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;

-- 테이블 데이터 coffee.Product:~11 rows (대략적) 내보내기
DELETE FROM `Product`;
/*!40000 ALTER TABLE `Product` DISABLE KEYS */;
INSERT INTO `Product` (`Product_Number`, `Roasting_Number`, `Bean_Number`, `Product_Gram`, `package_Date`, `Released_Date`, `Machine_Number`, `End_Check`) VALUES
	(1, 25, 5, 20, '2019-03-19 18:08:22', NULL, 3, 'E'),
	(2, 25, 5, 20, '2019-03-19 18:42:14', '2019-03-20 10:56:31', 3, 'Y'),
	(3, 24, 2, 10, '2019-03-19 18:45:39', '2019-03-20 10:56:52', 2, 'Y'),
	(4, 26, 6, 20, '2019-03-10 18:48:24', '2019-03-20 14:47:45', 2, 'E'),
	(5, 28, 1, 20, '2019-03-10 14:32:23', NULL, 1, 'N'),
	(6, 29, 3, 20, '2019-03-10 14:32:28', NULL, 3, 'N'),
	(7, 27, 4, 20, '2019-03-10 14:32:30', '2019-03-20 14:47:47', 2, 'Y'),
	(8, 30, 1, 10, '2019-03-10 14:34:50', NULL, 1, 'N'),
	(9, 31, 6, 20, '2019-03-10 14:34:53', '2019-03-20 14:47:48', 2, 'E'),
	(10, 32, 5, 15, '2019-03-10 14:34:56', NULL, 3, 'N'),
	(11, 31, 6, 20, '2019-03-20 14:47:27', NULL, 2, 'N'),
	(12, 32, 5, 15, '2019-03-20 14:47:29', NULL, 3, 'N'),
	(13, 33, 2, 20, '2019-03-20 14:47:31', NULL, 1, 'N');
/*!40000 ALTER TABLE `Product` ENABLE KEYS */;

-- 테이블 coffee.Roasting 구조 내보내기
CREATE TABLE IF NOT EXISTS `Roasting` (
  `Roasting_Number` int(11) NOT NULL AUTO_INCREMENT,
  `Bean_Number` int(11) NOT NULL,
  `Machine_Number` int(11) NOT NULL,
  `Roasting_Date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `RoastingEnd_Date` datetime DEFAULT NULL,
  `Roasting_Gram` int(11) NOT NULL DEFAULT '0',
  `Roasting_Check` varchar(10) NOT NULL DEFAULT 'N',
  PRIMARY KEY (`Roasting_Number`),
  KEY `FK_Roasting_Bean` (`Bean_Number`),
  KEY `FK_Roasting_Machine` (`Machine_Number`),
  CONSTRAINT `FK_Roasting_Bean` FOREIGN KEY (`Bean_Number`) REFERENCES `Bean` (`Bean_Number`),
  CONSTRAINT `FK_Roasting_Machine` FOREIGN KEY (`Machine_Number`) REFERENCES `Machine` (`Machine_Number`)
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=utf8;

-- 테이블 데이터 coffee.Roasting:~29 rows (대략적) 내보내기
DELETE FROM `Roasting`;
/*!40000 ALTER TABLE `Roasting` DISABLE KEYS */;
INSERT INTO `Roasting` (`Roasting_Number`, `Bean_Number`, `Machine_Number`, `Roasting_Date`, `RoastingEnd_Date`, `Roasting_Gram`, `Roasting_Check`) VALUES
	(3, 1, 1, '2019-03-05 11:31:20', NULL, 5, 'Y'),
	(4, 1, 2, '2019-03-05 11:31:31', NULL, 2, 'Y'),
	(5, 1, 1, '2019-03-05 11:31:37', NULL, 5, 'Y'),
	(6, 2, 1, '2019-03-05 16:04:26', NULL, 15, 'Y'),
	(7, 2, 1, '2019-03-14 14:33:27', NULL, 10, 'Y'),
	(8, 2, 1, '2019-03-14 14:34:01', NULL, 10, 'Y'),
	(9, 3, 2, '2019-03-14 14:39:22', NULL, 15, 'Y'),
	(10, 1, 2, '2019-03-14 16:40:23', NULL, 5, 'Y'),
	(11, 6, 2, '2019-03-14 16:57:52', NULL, 20, 'Y'),
	(15, 1, 2, '2019-03-15 10:27:21', '2019-03-15 16:27:21', 3, 'Y'),
	(16, 2, 3, '2019-03-15 10:30:11', '2019-03-15 16:30:11', 10, 'Y'),
	(17, 2, 3, '2019-03-15 10:31:32', '2019-03-15 16:31:32', 10, 'Y'),
	(18, 4, 3, '2019-03-15 10:56:31', '2019-03-15 16:56:31', 5, 'Y'),
	(19, 6, 2, '2019-03-15 11:23:45', '2019-03-15 17:23:45', 5, 'Y'),
	(20, 2, 2, '2019-03-15 11:24:30', '2019-03-15 17:24:30', 1, 'Y'),
	(21, 5, 1, '2019-03-15 11:28:24', '2019-03-15 17:28:24', 5, 'Y'),
	(22, 3, 2, '2019-03-15 11:41:29', '2019-03-15 17:41:29', 1, 'Y'),
	(23, 2, 1, '2019-03-15 17:08:27', '2019-03-15 23:08:27', 10, 'Y'),
	(24, 2, 2, '2019-03-18 12:01:02', '2019-03-18 18:01:02', 10, 'Y'),
	(25, 5, 3, '2019-03-19 10:31:44', '2019-03-15 16:31:44', 20, 'Y'),
	(26, 6, 2, '2019-03-19 18:47:25', '2019-03-10 00:47:25', 20, 'Y'),
	(27, 4, 2, '2019-03-20 10:18:01', '2019-03-10 15:18:01', 20, 'Y'),
	(28, 1, 1, '2019-03-20 10:20:38', '2019-03-10 16:20:38', 20, 'Y'),
	(29, 3, 3, '2019-03-19 21:29:29', '2019-03-10 17:29:29', 20, 'Y'),
	(30, 1, 1, '2019-03-19 14:32:38', '2019-03-10 20:32:38', 10, 'Y'),
	(31, 6, 2, '2019-03-19 14:32:43', '2019-03-10 10:32:43', 20, 'Y'),
	(32, 5, 3, '2019-03-19 14:32:50', '2019-03-10 10:32:50', 15, 'Y'),
	(33, 2, 1, '2019-03-20 14:41:16', '2019-03-20 11:41:16', 20, 'Y'),
	(34, 2, 2, '2019-03-20 14:47:13', '2019-03-20 20:47:13', 20, 'N');
/*!40000 ALTER TABLE `Roasting` ENABLE KEYS */;

-- 프로시저 coffee.Seting_Insert 구조 내보내기
DELIMITER //
CREATE DEFINER=`root`@`%` PROCEDURE `Seting_Insert`(
	IN `_Bean_Number` int,
	IN `_Gram` int,
	IN `_Machine_Number` INT,
	IN `_Setting_Time` int



)
BEGIN
INSERT INTO Roasting(Bean_Number,Machine_Number,Roasting_Gram,RoastingEnd_Date) 
VALUES (_Bean_Number, _Machine_Number, _Gram,DATE_ADD(NOW(), INTERVAL _Setting_Time HOUR));
update Machine set Fs_Check = 'Y' Where Machine_Number = _Machine_Number;
update Machine set Roasting_Time = _Setting_Time Where Machine_Number = _Machine_Number;
UPDATE Bean SET Gram = case when Gram < _Gram then 0 else (Gram - _Gram) end WHERE Bean_Number = _Bean_Number;
END//
DELIMITER ;

-- 프로시저 coffee.Seting_Machine 구조 내보내기
DELIMITER //
CREATE DEFINER=`root`@`%` PROCEDURE `Seting_Machine`( in _Roasting_Degree VARCHAR(255),in _Roasting_Time VARCHAR(255),in _Ripening_Time VARCHAR(255),IN _Machin_Number int)
BEGIN

UPDATE Machine
SET Roasting_Degree = _Roasting_Degree,
	 Roasting_Time = _Roasting_Time,
	 Ripening_Time = _Ripening_Time,
	 Fs_Check = 'Y'
WHERE Machine_Number = _Machine_Number AND Fs_Check = 'N';


END//
DELIMITER ;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
