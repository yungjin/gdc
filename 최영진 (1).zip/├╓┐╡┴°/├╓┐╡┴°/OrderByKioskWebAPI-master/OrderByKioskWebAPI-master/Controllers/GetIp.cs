using System.Net.NetworkInformation;
using System.Net.Sockets;

public class GetIP
    {
        // public string GetIP()
        // {
        //     IPHostEntry hostEntry = Dns.GetHostEntry(Dns.GetHostName());
        //     string ip = "";

        //     for (int i = 0; i < hostEntry.AddressList.Length; i++)
        //     {
        //         if(hostEntry.AddressList[i].AddressFamily == AddressFamily.InterNetwork)
        //         {
        //             ip = hostEntry.AddressList[i].ToString();
        //         }
        //     }
        //     Console.WriteLine("--------------{0}",ip);
        //     return ip;
        // }
       public static string GetLocalIPv4(NetworkInterfaceType _type)
        {
            string output = "";
            foreach (NetworkInterface item in NetworkInterface.GetAllNetworkInterfaces())
            {
                if (item.NetworkInterfaceType == _type && item.OperationalStatus == OperationalStatus.Up)
                {
                    foreach (UnicastIPAddressInformation ip in item.GetIPProperties().UnicastAddresses)
                    {
                        if (ip.Address.AddressFamily == AddressFamily.InterNetwork)
                        {
                            output = ip.Address.ToString();
                        }
                    }
                }
            }
            return output;
        }
        
    }   