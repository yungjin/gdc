﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GDtest
{
    class Class1
    {
        private SqlConnection conn;
        private Form1 form;
        private Form2 form2;

        public Class1(Form1 form)
        {
            this.form = (Form1)form;

            conn = new SqlConnection();
            string server = "(localdb)\\MSSQLLocalDB";
            string uid = "root";
            string password = "1234";
            string database = "test";
            conn.ConnectionString = string.Format("server={0};uid={1};password={2};database={3}", server, uid, password, database);
            try
            {
                conn.Open();
            }
            catch
            {
                MessageBox.Show("DB 오류");
            }
        }

        public Class1(Form2 form2)
        {
            this.form2 = (Form2)form2;

            conn = new SqlConnection();
            string server = "(localdb)\\MSSQLLocalDB";
            string uid = "root";
            string password = "1234";
            string database = "test";
            conn.ConnectionString = string.Format("server={0};uid={1};password={2};database={3}", server, uid, password, database);
            try
            {
                conn.Open();
            }
            catch
            {
                MessageBox.Show("DB 오류");
            }
        }

        public void Read()
        {
            try
            {
                SqlCommand comm = new SqlCommand("sp_GD_select", conn);
                comm.CommandType = CommandType.StoredProcedure;
                SqlDataReader sdr = comm.ExecuteReader();
                form.listView1.Items.Clear();
                while (sdr.Read())
                {
                    string[] arr = new string[6];
                    for (int i = 0; i < sdr.FieldCount; i++)
                    {
                        arr[i] = sdr.GetValue(i).ToString();
                    }
                    form.listView1.Items.Add(new ListViewItem(arr));
                }
                sdr.Close();
                //conn.Close();
            }
            catch
            {
                MessageBox.Show("연결 실패");
            }
        }

        public void CUD(string commandText, bool key1, bool key2, bool key3, string no) 
        {
            try
            {
                //conn.Open();
                SqlCommand comm = new SqlCommand(commandText, conn);
                comm.CommandType = CommandType.StoredProcedure;

                if (key1)
                {
                    comm.Parameters.AddWithValue("@no", no);
                }
                if (key2)
                {
                    string Title = form2.textBox1.Text;
                    string Contents = form2.textBox2.Text;

                    comm.Parameters.AddWithValue("@Title", Title);
                    comm.Parameters.AddWithValue("@Contents", Contents);
                }
                if (key3)
                {
                    string Name = form2.textBox3.Text;
                    string Passod = form2.textBox4.Text;

                    comm.Parameters.AddWithValue("@Name", Name);
                    comm.Parameters.AddWithValue("@Passod", Passod);
                }

                comm.ExecuteNonQuery();
                //conn.Close();
                MessageBox.Show("성공");
            }
            catch
            {
                MessageBox.Show("실패");
            }

            Read();
        }



    }
}
