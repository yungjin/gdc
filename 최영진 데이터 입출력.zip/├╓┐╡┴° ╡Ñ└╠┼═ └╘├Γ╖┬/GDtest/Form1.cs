﻿using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GDtest
{
    public partial class Form1 : Form
    {
        private Class1 comm;
        private string no;

        public Form1()
        {
            InitializeComponent();
            Load += Form1_Load;

            comm = new Class1(this);
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            listView1.MouseClick += list_Click;
            listView1.FullRowSelect = true;
            GetData();
        }

        private void list_Click(object sender, MouseEventArgs e)
        {
            
        }

        private void insert1_Click(object sender, EventArgs e)
        {
            Form2 insertForm = new Form2();
            insertForm.ShowDialog();
        }

        private void GetData()
        {
            try
            {
                WebClient wc = new WebClient();
                NameValueCollection nvc = new NameValueCollection();
                wc.Encoding = Encoding.UTF8;
                string data = wc.UploadString("http://localhost:5000/api/Select", "");
                Hashtable ht = JsonConvert.DeserializeObject<Hashtable>(data);
                if ("0" == ht["msgCode"].ToString())
                {
                    MessageBox.Show("오류 발생!");
                    return;
                }

                listView1.Items.Clear();
                ArrayList resultList = JsonConvert.DeserializeObject<ArrayList>(ht["data"].ToString());
                for (int i = 0; i < resultList.Count; i++)
                {
                    JObject jo = (JObject)resultList[i];
                    string bNo = jo.GetValue("bNo").ToString();
                    string Title = jo.GetValue("Title").ToString();
                    string Name = jo.GetValue("Name").ToString();
                    string ViewsNo = jo.GetValue("ViewsNo").ToString();

                    listView1.Items.Add(new ListViewItem(new string[] { bNo, Title, Name, ViewsNo}));
                }
            }
            catch
            {
                MessageBox.Show("네트워크 오류 발생!");
            }
        }
    }
}
